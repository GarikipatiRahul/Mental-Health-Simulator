import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMoodEntrySchema, type MoodEntry } from "@shared/schema";
import { getRandomQuote } from "./data/quotes";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get session data
  app.get("/api/session/:name", async (req, res) => {
    try {
      const { name } = req.params;
      const session = await storage.getSession(name);
      
      if (!session) {
        return res.json({ name, moodHistory: [] });
      }
      
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch session" });
    }
  });

  // Log mood entry
  app.post("/api/moods", async (req, res) => {
    try {
      const validatedData = insertMoodEntrySchema.parse(req.body);
      const entry = await storage.createMoodEntry(validatedData);
      
      // Update session with new entry
      const session = await storage.getSession(req.body.userName || "Anonymous");
      const updatedHistory = session ? [...session.moodHistory, entry] : [entry];
      await storage.createOrUpdateSession(req.body.userName || "Anonymous", updatedHistory);
      
      res.json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid mood entry data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to log mood entry" });
      }
    }
  });

  // Get random quote
  app.get("/api/quote", async (req, res) => {
    try {
      const quote = getRandomQuote();
      res.json(quote);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quote" });
    }
  });

  // Export mood data
  app.get("/api/export/:name", async (req, res) => {
    try {
      const { name } = req.params;
      const session = await storage.getSession(name);
      
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${name}_mood_data.json"`);
      res.json({
        name: session.name,
        exportDate: new Date().toISOString(),
        moodHistory: session.moodHistory
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to export data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
