import { Quote } from "@shared/schema";

export const motivationalQuotes: Quote[] = [
  {
    text: "The only way to do great work is to love what you do. If you haven't found it yet, keep looking. Don't settle.",
    author: "Steve Jobs"
  },
  {
    text: "Your mental health is a priority. Your happiness is an essential. Your self-care is a necessity.",
    author: "Unknown"
  },
  {
    text: "You don't have to be positive all the time. It's perfectly okay to feel sad, angry, annoyed, frustrated, scared, or anxious. Having feelings doesn't make you a negative person. It makes you human.",
    author: "Lori Deschene"
  },
  {
    text: "Mental health is not a destination, but a process. It's about how you drive, not where you're going.",
    author: "Noam Shpancer"
  },
  {
    text: "You are not your illness. You have an individual story to tell. You have a name, a history, a personality. Staying yourself is part of the battle.",
    author: "Julian Seifter"
  },
  {
    text: "Healing is not about moving on or getting over it, it's about learning to make peace with our pain and finding meaning in our struggle.",
    author: "Sheryl Sandberg"
  },
  {
    text: "The strongest people are not those who show strength in front of us, but those who win battles we know nothing about.",
    author: "Unknown"
  },
  {
    text: "It's okay to not be okay. It's okay to ask for help. It's okay to take time for yourself.",
    author: "Unknown"
  },
  {
    text: "You have been assigned this mountain to show others it can be moved.",
    author: "Mel Robbins"
  },
  {
    text: "Self-compassion is simply giving the same kindness to ourselves that we would give to others.",
    author: "Christopher Germer"
  }
];

export function getRandomQuote(): Quote {
  const randomIndex = Math.floor(Math.random() * motivationalQuotes.length);
  return motivationalQuotes[randomIndex];
}
