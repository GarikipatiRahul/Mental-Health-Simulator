import { Affirmation } from "@shared/schema";

export const dailyAffirmations: Affirmation[] = [
  {
    text: "I am worthy of love and happiness",
    category: "self-love"
  },
  {
    text: "I have the strength to overcome any challenge",
    category: "strength"
  },
  {
    text: "I choose peace over worry",
    category: "anxiety"
  },
  {
    text: "I am grateful for all the good in my life",
    category: "gratitude"
  },
  {
    text: "I believe in my ability to figure things out",
    category: "confidence"
  },
  {
    text: "I am becoming the best version of myself",
    category: "growth"
  },
  {
    text: "I deserve to take up space in this world",
    category: "self-worth"
  },
  {
    text: "I trust the process of life",
    category: "trust"
  },
  {
    text: "I am resilient and can handle whatever comes my way",
    category: "resilience"
  },
  {
    text: "I choose to focus on what I can control",
    category: "control"
  },
  {
    text: "I am learning and growing every day",
    category: "growth"
  },
  {
    text: "I am enough, just as I am",
    category: "self-acceptance"
  },
  {
    text: "I release what no longer serves me",
    category: "letting-go"
  },
  {
    text: "I attract positive energy into my life",
    category: "positivity"
  },
  {
    text: "I am creating a life I love",
    category: "purpose"
  }
];

export function getRandomAffirmation(): Affirmation {
  const randomIndex = Math.floor(Math.random() * dailyAffirmations.length);
  return dailyAffirmations[randomIndex];
}

export function getAffirmationByCategory(category: string): Affirmation[] {
  return dailyAffirmations.filter(affirmation => 
    affirmation.category === category
  );
}