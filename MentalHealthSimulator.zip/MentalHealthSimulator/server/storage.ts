import { 
  users, 
  moodEntries, 
  journalEntries,
  moodGoals,
  userStreaks,
  type User, 
  type InsertUser, 
  type MoodEntry, 
  type InsertMoodEntry,
  type JournalEntry,
  type InsertJournalEntry,
  type MoodGoal,
  type InsertMoodGoal,
  type UserStreak,
  type InsertUserStreak,
  type Session 
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry>;
  getMoodEntriesByUserId(userId: number): Promise<MoodEntry[]>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;
  getJournalEntriesByUserId(userId: number): Promise<JournalEntry[]>;
  createMoodGoal(goal: InsertMoodGoal): Promise<MoodGoal>;
  getMoodGoalsByUserId(userId: number): Promise<MoodGoal[]>;
  updateMoodGoal(id: number, goal: Partial<MoodGoal>): Promise<MoodGoal>;
  getUserStreak(userId: number): Promise<UserStreak | undefined>;
  updateUserStreak(userId: number, streak: InsertUserStreak): Promise<UserStreak>;
  getSession(name: string): Promise<Session | undefined>;
  createOrUpdateSession(name: string, moodHistory: MoodEntry[]): Promise<Session>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createMoodEntry(insertEntry: InsertMoodEntry): Promise<MoodEntry> {
    const [entry] = await db
      .insert(moodEntries)
      .values(insertEntry)
      .returning();
    return entry;
  }

  async getMoodEntriesByUserId(userId: number): Promise<MoodEntry[]> {
    return await db.select().from(moodEntries).where(eq(moodEntries.userId, userId));
  }

  async createJournalEntry(insertEntry: InsertJournalEntry): Promise<JournalEntry> {
    const [entry] = await db
      .insert(journalEntries)
      .values(insertEntry)
      .returning();
    return entry;
  }

  async getJournalEntriesByUserId(userId: number): Promise<JournalEntry[]> {
    return await db.select().from(journalEntries).where(eq(journalEntries.userId, userId));
  }

  async createMoodGoal(insertGoal: InsertMoodGoal): Promise<MoodGoal> {
    const [goal] = await db
      .insert(moodGoals)
      .values(insertGoal)
      .returning();
    return goal;
  }

  async getMoodGoalsByUserId(userId: number): Promise<MoodGoal[]> {
    return await db.select().from(moodGoals).where(eq(moodGoals.userId, userId));
  }

  async updateMoodGoal(id: number, goalUpdate: Partial<MoodGoal>): Promise<MoodGoal> {
    const [goal] = await db
      .update(moodGoals)
      .set(goalUpdate)
      .where(eq(moodGoals.id, id))
      .returning();
    return goal;
  }

  async getUserStreak(userId: number): Promise<UserStreak | undefined> {
    const [streak] = await db.select().from(userStreaks).where(eq(userStreaks.userId, userId));
    return streak || undefined;
  }

  async updateUserStreak(userId: number, streakData: InsertUserStreak): Promise<UserStreak> {
    const existing = await this.getUserStreak(userId);
    
    if (existing) {
      const [streak] = await db
        .update(userStreaks)
        .set(streakData)
        .where(eq(userStreaks.userId, userId))
        .returning();
      return streak;
    } else {
      const [streak] = await db
        .insert(userStreaks)
        .values(streakData)
        .returning();
      return streak;
    }
  }

  async getSession(name: string): Promise<Session | undefined> {
    // For database implementation, we'll simulate session by getting mood history
    const moodHistory = await db.select().from(moodEntries).where(eq(moodEntries.userId, 1));
    
    if (moodHistory.length === 0) {
      return undefined;
    }
    
    return { name, moodHistory };
  }

  async createOrUpdateSession(name: string, moodHistory: MoodEntry[]): Promise<Session> {
    // For database implementation, session is virtual - just return the data
    return { name, moodHistory };
  }
}

export const storage = new DatabaseStorage();
