import { pgTable, text, serial, integer, timestamp, boolean, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mood: text("mood").notNull(),
  emoji: text("emoji").notNull(),
  notes: text("notes"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  tags: text("tags").array().notNull().default([]),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const moodGoals = pgTable("mood_goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  targetMood: text("target_mood").notNull(),
  targetEmoji: text("target_emoji").notNull(),
  description: text("description").notNull(),
  targetDate: date("target_date").notNull(),
  isCompleted: boolean("is_completed").notNull().default(false),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const userStreaks = pgTable("user_streaks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  lastCheckIn: date("last_check_in"),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  moodEntries: many(moodEntries),
  journalEntries: many(journalEntries),
  moodGoals: many(moodGoals),
  streak: many(userStreaks),
}));

export const moodEntriesRelations = relations(moodEntries, ({ one }) => ({
  user: one(users, {
    fields: [moodEntries.userId],
    references: [users.id],
  }),
}));

export const journalEntriesRelations = relations(journalEntries, ({ one }) => ({
  user: one(users, {
    fields: [journalEntries.userId],
    references: [users.id],
  }),
}));

export const moodGoalsRelations = relations(moodGoals, ({ one }) => ({
  user: one(users, {
    fields: [moodGoals.userId],
    references: [users.id],
  }),
}));

export const userStreaksRelations = relations(userStreaks, ({ one }) => ({
  user: one(users, {
    fields: [userStreaks.userId],
    references: [users.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({
  id: true,
  timestamp: true,
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).omit({
  id: true,
  timestamp: true,
});

export const insertMoodGoalSchema = createInsertSchema(moodGoals).omit({
  id: true,
  timestamp: true,
});

export const insertUserStreakSchema = createInsertSchema(userStreaks).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type MoodGoal = typeof moodGoals.$inferSelect;
export type InsertMoodGoal = z.infer<typeof insertMoodGoalSchema>;
export type UserStreak = typeof userStreaks.$inferSelect;
export type InsertUserStreak = z.infer<typeof insertUserStreakSchema>;

// Client-side types
export interface Session {
  name: string;
  moodHistory: MoodEntry[];
}

export interface MoodOption {
  name: string;
  emoji: string;
  color: string;
}

export interface Quote {
  text: string;
  author: string;
}

export interface Affirmation {
  text: string;
  category: string;
}

export interface JournalEntry {
  id: number;
  userId: number;
  title: string;
  content: string;
  tags: string[];
  timestamp: Date;
}

export interface MoodGoal {
  id: number;
  userId: number;
  targetMood: string;
  targetEmoji: string;
  description: string;
  targetDate: Date;
  isCompleted: boolean;
  timestamp: Date;
}

export interface MoodStreak {
  currentStreak: number;
  longestStreak: number;
  lastCheckIn: Date | null;
}
