import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Check, Smile } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MoodLoggingProps {
  userName: string;
  onMoodLogged: (mood: string, emoji: string, notes?: string) => void;
}

const moodOptions = [
  { name: "Happy", emoji: "😊", color: "border-secondary hover:border-secondary hover:bg-secondary/5" },
  { name: "Sad", emoji: "😢", color: "border-blue-400 hover:border-blue-400 hover:bg-blue-50" },
  { name: "Anxious", emoji: "😰", color: "border-yellow-400 hover:border-yellow-400 hover:bg-yellow-50" },
  { name: "Excited", emoji: "🤩", color: "border-pink-400 hover:border-pink-400 hover:bg-pink-50" },
  { name: "Calm", emoji: "😌", color: "border-green-400 hover:border-green-400 hover:bg-green-50" },
  { name: "Stressed", emoji: "😤", color: "border-red-400 hover:border-red-400 hover:bg-red-50" },
];

export default function MoodLogging({ userName, onMoodLogged }: MoodLoggingProps) {
  const [selectedMood, setSelectedMood] = useState<typeof moodOptions[0] | null>(null);
  const [notes, setNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const logMoodMutation = useMutation({
    mutationFn: async (data: { mood: string; emoji: string; notes?: string; userName: string }) => {
      const response = await apiRequest('POST', '/api/moods', {
        userId: 1, // Using dummy userId for now
        mood: data.mood,
        emoji: data.emoji,
        notes: data.notes || null,
        userName: data.userName
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/session'] });
      if (selectedMood) {
        onMoodLogged(selectedMood.name, selectedMood.emoji, notes);
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log your mood. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMood) {
      toast({
        title: "Please select a mood",
        description: "Choose an emotion that best describes your current state.",
        variant: "destructive",
      });
      return;
    }

    logMoodMutation.mutate({
      mood: selectedMood.name,
      emoji: selectedMood.emoji,
      notes: notes.trim() || undefined,
      userName
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl shadow-2xl shadow-primary/10 border-0 rounded-3xl">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-slate-800 mb-2 flex items-center justify-center">
              <Smile className="text-accent mr-2 h-6 w-6" />
              How are you feeling today?
            </h2>
            <p className="text-slate-600">Select the emotion that best describes your current state</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Mood Selection Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {moodOptions.map((mood) => (
                <button
                  key={mood.name}
                  type="button"
                  onClick={() => setSelectedMood(mood)}
                  className={`p-6 border-2 rounded-2xl transition-all duration-200 text-center group ${
                    selectedMood?.name === mood.name 
                      ? 'border-primary bg-primary/5' 
                      : `border-slate-200 ${mood.color}`
                  }`}
                >
                  <div className="text-4xl mb-2">{mood.emoji}</div>
                  <div className={`font-semibold ${
                    selectedMood?.name === mood.name 
                      ? 'text-primary' 
                      : 'text-slate-700 group-hover:text-primary'
                  }`}>
                    {mood.name}
                  </div>
                </button>
              ))}
            </div>

            {/* Optional Notes */}
            <div>
              <Label className="block text-sm font-semibold text-slate-700 mb-2">
                Additional notes (optional)
              </Label>
              <Textarea 
                placeholder="Tell us more about how you're feeling..." 
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="px-4 py-3 border-2 border-slate-200 rounded-xl focus:border-primary focus:ring-4 focus:ring-primary/20 transition-all duration-200 resize-none"
                rows={3}
              />
            </div>

            <Button 
              type="submit"
              disabled={logMoodMutation.isPending}
              className="w-full bg-gradient-to-r from-secondary to-green-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg hover:scale-105 transition-all duration-300 h-auto"
            >
              <Check className="mr-2 h-5 w-5" />
              {logMoodMutation.isPending ? "Logging..." : "Log My Mood"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
