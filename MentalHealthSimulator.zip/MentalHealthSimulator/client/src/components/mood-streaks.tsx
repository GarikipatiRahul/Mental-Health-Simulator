import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, Flame, Trophy, TrendingUp, Clock, Star } from "lucide-react";
import { MoodEntry } from "@shared/schema";

interface MoodStreaksProps {
  userName: string;
  onBack: () => void;
}

export default function MoodStreaks({ userName, onBack }: MoodStreaksProps) {
  const { data: session } = useQuery({
    queryKey: ['/api/session', userName],
    enabled: !!userName
  });

  const moodHistory: MoodEntry[] = session?.moodHistory || [];

  const streakData = useMemo(() => {
    if (moodHistory.length === 0) {
      return {
        currentStreak: 0,
        longestStreak: 0,
        lastCheckIn: null,
        weeklyStreak: 0,
        monthlyGoal: 0,
        positiveMoodStreak: 0
      };
    }

    // Sort entries by date
    const sortedEntries = [...moodHistory].sort((a, b) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    // Calculate current streak (consecutive days)
    let currentStreak = 0;
    let longestStreak = 0;
    let tempStreak = 1;
    
    const today = new Date();
    const lastEntry = sortedEntries[sortedEntries.length - 1];
    const lastCheckIn = new Date(lastEntry.timestamp);
    
    // Check if user checked in today or yesterday
    const daysSinceLastCheckIn = Math.floor((today.getTime() - lastCheckIn.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysSinceLastCheckIn <= 1) {
      currentStreak = 1;
      
      // Count backwards for consecutive days
      for (let i = sortedEntries.length - 2; i >= 0; i--) {
        const currentDate = new Date(sortedEntries[i + 1].timestamp);
        const prevDate = new Date(sortedEntries[i].timestamp);
        const dayDiff = Math.floor((currentDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (dayDiff === 1) {
          currentStreak++;
        } else {
          break;
        }
      }
    }

    // Calculate longest streak
    for (let i = 1; i < sortedEntries.length; i++) {
      const currentDate = new Date(sortedEntries[i].timestamp);
      const prevDate = new Date(sortedEntries[i - 1].timestamp);
      const dayDiff = Math.floor((currentDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (dayDiff === 1) {
        tempStreak++;
      } else {
        longestStreak = Math.max(longestStreak, tempStreak);
        tempStreak = 1;
      }
    }
    longestStreak = Math.max(longestStreak, tempStreak);

    // Calculate weekly streak (last 7 days)
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const weeklyEntries = sortedEntries.filter(entry => 
      new Date(entry.timestamp) >= weekAgo
    );
    const uniqueDaysThisWeek = new Set(
      weeklyEntries.map(entry => 
        new Date(entry.timestamp).toDateString()
      )
    ).size;

    // Calculate monthly goal (target: 20 days this month)
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthlyEntries = sortedEntries.filter(entry => 
      new Date(entry.timestamp) >= monthStart
    );
    const uniqueDaysThisMonth = new Set(
      monthlyEntries.map(entry => 
        new Date(entry.timestamp).toDateString()
      )
    ).size;

    // Calculate positive mood streak
    const positiveMoods = ['Happy', 'Excited', 'Calm', 'Grateful'];
    let positiveMoodStreak = 0;
    for (let i = sortedEntries.length - 1; i >= 0; i--) {
      if (positiveMoods.includes(sortedEntries[i].mood)) {
        positiveMoodStreak++;
      } else {
        break;
      }
    }

    return {
      currentStreak,
      longestStreak,
      lastCheckIn,
      weeklyStreak: uniqueDaysThisWeek,
      monthlyGoal: Math.round((uniqueDaysThisMonth / 20) * 100),
      positiveMoodStreak
    };
  }, [moodHistory]);

  const getStreakLevel = (streak: number) => {
    if (streak >= 30) return { level: "Master", color: "text-purple-600", bg: "bg-purple-100" };
    if (streak >= 14) return { level: "Expert", color: "text-blue-600", bg: "bg-blue-100" };
    if (streak >= 7) return { level: "Committed", color: "text-green-600", bg: "bg-green-100" };
    if (streak >= 3) return { level: "Building", color: "text-yellow-600", bg: "bg-yellow-100" };
    return { level: "Starting", color: "text-gray-600", bg: "bg-gray-100" };
  };

  const currentLevel = getStreakLevel(streakData.currentStreak);

  return (
    <div className="min-h-screen bg-slate-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <Card className="shadow-lg border-0 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center">
                <Flame className="text-orange-500 mr-3 h-8 w-8" />
                Mood Streaks
              </h2>
              <p className="text-slate-600">Track your consistency in emotional wellness</p>
            </div>
            <Button onClick={onBack} variant="outline" className="rounded-xl">
              Back to Dashboard
            </Button>
          </div>
        </Card>

        {/* Current Streak Highlight */}
        <Card className="shadow-lg border-0 rounded-2xl p-8 mb-6 bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <Flame className="text-orange-500 h-16 w-16" />
            </div>
            <div className="text-6xl font-bold text-orange-600 mb-2">
              {streakData.currentStreak}
            </div>
            <div className="text-xl text-slate-700 mb-4">
              Day{streakData.currentStreak !== 1 ? 's' : ''} Current Streak
            </div>
            <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${currentLevel.bg} ${currentLevel.color}`}>
              <Star className="h-4 w-4 mr-2" />
              {currentLevel.level} Level
            </div>
          </div>
        </Card>

        {/* Streak Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          {/* Longest Streak */}
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-blue-500/20 rounded-lg">
                <Trophy className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <div className="text-3xl font-bold text-slate-800">{streakData.longestStreak}</div>
                <div className="text-sm text-slate-600">Longest Streak</div>
                <div className="text-xs text-blue-600 font-medium">Personal Best!</div>
              </div>
            </div>
          </Card>

          {/* Weekly Progress */}
          <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-green-500/20 rounded-lg">
                <Calendar className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <div className="text-3xl font-bold text-slate-800">{streakData.weeklyStreak}/7</div>
                <div className="text-sm text-slate-600">This Week</div>
                <div className="w-20 bg-green-200 rounded-full h-2 mt-1">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min((streakData.weeklyStreak / 7) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </Card>

          {/* Monthly Goal */}
          <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-purple-500/20 rounded-lg">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <div className="text-3xl font-bold text-slate-800">{streakData.monthlyGoal}%</div>
                <div className="text-sm text-slate-600">Monthly Goal</div>
                <div className="text-xs text-purple-600 font-medium">20 days target</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Additional Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Positive Mood Streak */}
          <Card className="shadow-lg border-0 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
              <Star className="text-yellow-500 mr-2 h-5 w-5" />
              Positive Mood Streak
            </h3>
            <div className="text-center py-6">
              <div className="text-4xl font-bold text-yellow-600 mb-2">
                {streakData.positiveMoodStreak}
              </div>
              <div className="text-slate-600">
                Consecutive positive mood entries
              </div>
              <div className="mt-4 text-sm text-slate-500">
                Keep logging happy, excited, calm, or grateful moods!
              </div>
            </div>
          </Card>

          {/* Last Check-in */}
          <Card className="shadow-lg border-0 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
              <Clock className="text-slate-600 mr-2 h-5 w-5" />
              Recent Activity
            </h3>
            <div className="space-y-4">
              {streakData.lastCheckIn ? (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Last Check-in:</span>
                    <span className="font-medium text-slate-800">
                      {new Date(streakData.lastCheckIn).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Total Entries:</span>
                    <span className="font-medium text-slate-800">{moodHistory.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">This Month:</span>
                    <span className="font-medium text-slate-800">
                      {moodHistory.filter(entry => {
                        const entryDate = new Date(entry.timestamp);
                        const now = new Date();
                        return entryDate.getMonth() === now.getMonth() && 
                               entryDate.getFullYear() === now.getFullYear();
                      }).length} entries
                    </span>
                  </div>
                </>
              ) : (
                <div className="text-center py-6 text-slate-500">
                  <Clock className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No mood entries yet. Start your streak today!</p>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Motivation Section */}
        <Card className="shadow-lg border-0 rounded-2xl p-6">
          <h3 className="text-xl font-bold text-slate-800 mb-4">Keep Going!</h3>
          <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-xl p-6">
            <div className="text-center">
              {streakData.currentStreak === 0 ? (
                <p className="text-slate-700 text-lg">
                  Start your wellness journey today! Every expert was once a beginner.
                </p>
              ) : streakData.currentStreak < 7 ? (
                <p className="text-slate-700 text-lg">
                  Great start! You're building a healthy habit. Keep it up for {7 - streakData.currentStreak} more days to reach the next level.
                </p>
              ) : streakData.currentStreak < 14 ? (
                <p className="text-slate-700 text-lg">
                  Fantastic! You're showing real commitment. Just {14 - streakData.currentStreak} more days to become an Expert.
                </p>
              ) : streakData.currentStreak < 30 ? (
                <p className="text-slate-700 text-lg">
                  Incredible dedication! You're an Expert now. {30 - streakData.currentStreak} more days to reach Master level.
                </p>
              ) : (
                <p className="text-slate-700 text-lg">
                  You're a Master! Your dedication to mental wellness is truly inspiring. Keep up this amazing habit!
                </p>
              )}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}