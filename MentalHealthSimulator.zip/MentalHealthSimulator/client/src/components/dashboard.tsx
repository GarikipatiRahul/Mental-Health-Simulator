import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { 
  PieChart, 
  BarChart3, 
  Clock, 
  Gem, 
  Search, 
  RefreshCw, 
  Download, 
  Wind, 
  Plus,
  History,
  Info
} from "lucide-react";
import { MoodEntry } from "@shared/schema";

interface DashboardProps {
  userName: string;
  onRestartSession: () => void;
  onBreathingExercise: () => void;
  onLogNewMood: () => void;
  onMoodGoals: () => void;
  onMoodJournal: () => void;
  onMoodStreaks: () => void;
  onAffirmations: () => void;
}

export default function Dashboard({ 
  userName, 
  onRestartSession, 
  onBreathingExercise, 
  onLogNewMood,
  onMoodGoals,
  onMoodJournal,
  onMoodStreaks,
  onAffirmations
}: DashboardProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: session } = useQuery({
    queryKey: ['/api/session', userName],
    enabled: !!userName
  });

  const moodHistory: MoodEntry[] = session?.moodHistory || [];

  // DSA Demonstrations
  const moodFrequency = useMemo(() => {
    const frequency = new Map<string, number>();
    moodHistory.forEach(entry => {
      frequency.set(entry.mood, (frequency.get(entry.mood) || 0) + 1);
    });
    return frequency;
  }, [moodHistory]);

  const recentMoods = useMemo(() => {
    // Queue: FIFO - show last 5 moods
    return moodHistory.slice(-5).reverse();
  }, [moodHistory]);

  const uniqueMoods = useMemo(() => {
    // Set: unique values only
    const unique = new Set<string>();
    moodHistory.forEach(entry => unique.add(entry.mood));
    return unique;
  }, [moodHistory]);

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    
    // Find: search through mood history
    const query = searchQuery.toLowerCase();
    const results = moodHistory.filter(entry => 
      entry.mood.toLowerCase().includes(query) ||
      (entry.notes && entry.notes.toLowerCase().includes(query))
    );
    
    // Group by mood for frequency display
    const grouped = new Map<string, { count: number; emoji: string }>();
    results.forEach(entry => {
      const existing = grouped.get(entry.mood) || { count: 0, emoji: entry.emoji };
      grouped.set(entry.mood, { ...existing, count: existing.count + 1 });
    });
    
    return grouped;
  }, [searchQuery, moodHistory]);

  const handleExportData = async () => {
    try {
      const response = await fetch(`/api/export/${userName}`);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `${userName}_mood_data.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export data:', error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 animate-fade-in">
      <div className="max-w-7xl mx-auto">
        {/* Dashboard Header */}
        <Card className="shadow-lg border-0 rounded-2xl p-6 mb-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
            <div>
              <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center">
                <PieChart className="text-primary mr-3 h-8 w-8" />
                Mental Wellness Dashboard
              </h2>
              <p className="text-slate-600">Your emotional journey visualized through data structures</p>
            </div>
            <div className="mt-4 sm:mt-0">
              <Button 
                onClick={onRestartSession}
                className="bg-gradient-to-r from-accent to-orange-500 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition-all duration-300"
              >
                <RefreshCw className="mr-2 h-5 w-5" />
                New Session
              </Button>
            </div>
          </div>
        </Card>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          
          {/* Mood History (Array/List) */}
          <Card className="shadow-lg border-0 rounded-2xl p-6 xl:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800 flex items-center">
                <History className="text-primary mr-2 h-5 w-5" />
                Mood History <span className="text-sm font-normal text-slate-500 ml-2">(Array)</span>
              </h3>
              <div className="text-sm text-slate-500">{moodHistory.length} entries</div>
            </div>
            
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {moodHistory.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <History className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No mood entries yet. Start logging your moods to see your history here.</p>
                </div>
              ) : (
                moodHistory.slice().reverse().map((entry, index) => (
                  <div key={entry.id} className="flex items-center space-x-4 p-3 hover:bg-slate-50 rounded-lg transition-colors">
                    <div className="text-2xl">{entry.emoji}</div>
                    <div className="flex-1">
                      <div className="font-medium text-slate-800">{entry.mood}</div>
                      <div className="text-sm text-slate-500">
                        {new Date(entry.timestamp).toLocaleString()}
                      </div>
                      {entry.notes && (
                        <div className="text-sm text-slate-600 mt-1">"{entry.notes}"</div>
                      )}
                    </div>
                    <div className={`w-3 h-3 rounded-full ${
                      index % 3 === 0 ? 'bg-secondary' : index % 3 === 1 ? 'bg-primary' : 'bg-accent'
                    }`}></div>
                  </div>
                ))
              )}
            </div>
          </Card>

          {/* Mood Frequency (Map) */}
          <Card className="shadow-lg border-0 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800 flex items-center">
                <BarChart3 className="text-secondary mr-2 h-5 w-5" />
                Mood Frequency <span className="text-sm font-normal text-slate-500 ml-2">(Map)</span>
              </h3>
            </div>
            
            <div className="space-y-4">
              {moodFrequency.size === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <BarChart3 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>Start logging moods to see frequency data.</p>
                </div>
              ) : (
                Array.from(moodFrequency.entries())
                  .sort((a, b) => b[1] - a[1])
                  .map(([mood, count]) => {
                    const entry = moodHistory.find(e => e.mood === mood);
                    const maxCount = Math.max(...Array.from(moodFrequency.values()));
                    const percentage = (count / maxCount) * 100;
                    
                    return (
                      <div key={mood} className="flex items-center space-x-3">
                        <div className="text-xl">{entry?.emoji}</div>
                        <div className="flex-1">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium text-slate-700">{mood}</span>
                            <span className="text-sm text-slate-500">{count}</span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2">
                            <div 
                              className="bg-secondary h-2 rounded-full transition-all duration-500"
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    );
                  })
              )}
            </div>
          </Card>

          {/* Recent Moods (Queue) */}
          <Card className="shadow-lg border-0 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800 flex items-center">
                <Clock className="text-accent mr-2 h-5 w-5" />
                Recent Moods <span className="text-sm font-normal text-slate-500 ml-2">(Queue)</span>
              </h3>
              <div className="text-xs text-slate-500">Last 5</div>
            </div>
            
            <div className="space-y-3">
              {recentMoods.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <Clock className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>Recent moods will appear here.</p>
                </div>
              ) : (
                recentMoods.map((mood, index) => (
                  <div key={mood.id} className={`flex items-center justify-between p-3 bg-slate-50 rounded-lg border-l-4 ${
                    index === 0 ? 'border-primary' : index === 1 ? 'border-secondary' : 'border-accent'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-6 h-6 text-white rounded-full flex items-center justify-center text-xs font-bold ${
                        index === 0 ? 'bg-primary' : index === 1 ? 'bg-secondary' : 'bg-accent'
                      }`}>
                        {index + 1}
                      </div>
                      <span className="text-2xl">{mood.emoji}</span>
                      <span className="font-medium text-slate-700">{mood.mood}</span>
                    </div>
                    <div className="text-slate-400">→</div>
                  </div>
                ))
              )}
            </div>
          </Card>

          {/* Unique Moods (Set) */}
          <Card className="shadow-lg border-0 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800 flex items-center">
                <Gem className="text-purple-500 mr-2 h-5 w-5" />
                Unique Moods <span className="text-sm font-normal text-slate-500 ml-2">(Set)</span>
              </h3>
              <div className="text-xs text-slate-500">{uniqueMoods.size} unique</div>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              {uniqueMoods.size === 0 ? (
                <div className="col-span-3 text-center py-8 text-slate-500">
                  <Gem className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">Unique moods will appear here.</p>
                </div>
              ) : (
                Array.from(uniqueMoods).map(mood => {
                  const entry = moodHistory.find(e => e.mood === mood);
                  return (
                    <div key={mood} className="bg-gradient-to-br from-purple-50 to-pink-50 p-4 rounded-xl text-center border-2 border-purple-100 hover:border-purple-300 transition-colors">
                      <div className="text-2xl mb-1">{entry?.emoji}</div>
                      <div className="text-xs font-medium text-purple-700">{mood}</div>
                    </div>
                  );
                })
              )}
            </div>
          </Card>

          {/* Mood Search (Find) */}
          <Card className="shadow-lg border-0 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800 flex items-center">
                <Search className="text-blue-500 mr-2 h-5 w-5" />
                Mood Search <span className="text-sm font-normal text-slate-500 ml-2">(Find)</span>
              </h3>
            </div>
            
            <div className="space-y-4">
              <div className="relative">
                <Input 
                  type="text" 
                  placeholder="Search your moods..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-3 border-2 border-slate-200 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all duration-200"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
              </div>
              
              <div className="space-y-2">
                {searchQuery && searchResults instanceof Map && searchResults.size > 0 ? (
                  Array.from(searchResults.entries()).map(([mood, data]) => (
                    <div key={mood} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center space-x-3">
                        <span className="text-xl">{data.emoji}</span>
                        <div>
                          <div className="font-medium text-slate-800">{mood}</div>
                          <div className="text-sm text-slate-500">Found {data.count} times</div>
                        </div>
                      </div>
                      <div className="text-blue-500">→</div>
                    </div>
                  ))
                ) : searchQuery ? (
                  <div className="text-center py-4 text-slate-500 text-sm">
                    <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    No results found for "{searchQuery}"
                  </div>
                ) : (
                  <div className="text-center py-4 text-slate-500 text-sm">
                    <Info className="h-4 w-4 inline mr-2" />
                    Type to search through your mood history
                  </div>
                )}
              </div>
            </div>
          </Card>

        </div>

        {/* Quick Actions */}
        <Card className="mt-8 shadow-lg border-0 rounded-2xl p-6">
          <h3 className="text-xl font-bold text-slate-800 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button 
              onClick={onLogNewMood}
              className="bg-gradient-to-r from-primary to-indigo-600 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition-all duration-300 h-auto"
            >
              <Plus className="mr-2 h-5 w-5" />
              Log New Mood
            </Button>
            
            <Button 
              onClick={onBreathingExercise}
              className="bg-gradient-to-r from-secondary to-green-600 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition-all duration-300 h-auto"
            >
              <Wind className="mr-2 h-5 w-5" />
              Breathing Exercise
            </Button>
            
            <Button 
              onClick={onMoodStreaks}
              className="bg-gradient-to-r from-orange-500 to-red-600 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition-all duration-300 h-auto"
            >
              🔥 View Streaks
            </Button>
            
            <Button 
              onClick={handleExportData}
              className="bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition-all duration-300 h-auto"
            >
              <Download className="mr-2 h-5 w-5" />
              Export Data
            </Button>
          </div>
        </Card>

        {/* New Features */}
        <Card className="mt-6 shadow-lg border-0 rounded-2xl p-6">
          <h3 className="text-xl font-bold text-slate-800 mb-4">🌟 Wellness Tools</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Button 
              onClick={onMoodGoals}
              className="bg-gradient-to-r from-purple-500 to-pink-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg transition-all duration-300 h-auto flex flex-col items-center space-y-2"
            >
              🎯 <span>Mood Goals</span>
              <span className="text-xs opacity-80">Set & track emotional targets</span>
            </Button>
            
            <Button 
              onClick={onMoodJournal}
              className="bg-gradient-to-r from-green-500 to-teal-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg transition-all duration-300 h-auto flex flex-col items-center space-y-2"
            >
              📝 <span>Mood Journal</span>
              <span className="text-xs opacity-80">Write your thoughts & feelings</span>
            </Button>
            
            <Button 
              onClick={onAffirmations}
              className="bg-gradient-to-r from-pink-500 to-rose-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg transition-all duration-300 h-auto flex flex-col items-center space-y-2"
            >
              ✨ <span>Daily Affirmations</span>
              <span className="text-xs opacity-80">Positive thoughts for your day</span>
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
