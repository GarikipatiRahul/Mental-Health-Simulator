import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Pause, Play, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface BreathingExerciseProps {
  onComplete: () => void;
}

type BreathingPhase = "inhale" | "hold" | "exhale" | "pause";

export default function BreathingExercise({ onComplete }: BreathingExerciseProps) {
  const [isActive, setIsActive] = useState(true);
  const [currentCycle, setCurrentCycle] = useState(1);
  const [currentPhase, setCurrentPhase] = useState<BreathingPhase>("inhale");
  const [timeLeft, setTimeLeft] = useState(4);

  const totalCycles = 10;
  const phaseDurations = {
    inhale: 4,
    hold: 4,
    exhale: 4,
    pause: 2
  };

  const phaseInstructions = {
    inhale: "Breathe In",
    hold: "Hold",
    exhale: "Breathe Out",
    pause: "Rest"
  };

  useEffect(() => {
    if (!isActive) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev > 1) {
          return prev - 1;
        }

        // Move to next phase
        let nextPhase: BreathingPhase;
        let nextCycle = currentCycle;

        switch (currentPhase) {
          case "inhale":
            nextPhase = "hold";
            break;
          case "hold":
            nextPhase = "exhale";
            break;
          case "exhale":
            nextPhase = "pause";
            break;
          case "pause":
            nextPhase = "inhale";
            nextCycle = currentCycle + 1;
            break;
        }

        if (nextCycle > totalCycles) {
          setIsActive(false);
          return 0;
        }

        setCurrentPhase(nextPhase);
        setCurrentCycle(nextCycle);
        return phaseDurations[nextPhase];
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isActive, currentPhase, currentCycle]);

  const togglePause = () => {
    setIsActive(!isActive);
  };

  const handleComplete = () => {
    setIsActive(false);
    onComplete();
  };

  const getCircleScale = () => {
    switch (currentPhase) {
      case "inhale":
        return 1.2;
      case "hold":
        return 1.2;
      case "exhale":
        return 0.8;
      case "pause":
        return 1.0;
      default:
        return 1.0;
    }
  };

  const progressPercentage = ((currentCycle - 1) / totalCycles) * 100;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="text-center w-full max-w-lg">
        <Card className="bg-white/80 backdrop-blur-sm shadow-2xl border-0 rounded-3xl mb-8">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-slate-800 mb-4 flex items-center justify-center">
              <div className="w-6 h-6 mr-2 rounded-full bg-secondary"></div>
              Breathing Exercise
            </h2>
            <p className="text-slate-600 mb-6">
              Follow the circle and breathe slowly. Inhale as it grows, exhale as it shrinks.
            </p>
            
            {/* Breathing Circle Animation */}
            <div className="relative h-80 flex items-center justify-center mb-6">
              <div className="relative">
                {/* Outer ring */}
                <div className="w-64 h-64 rounded-full border-4 border-primary/20 absolute animate-pulse-gentle"></div>
                
                {/* Main breathing circle */}
                <AnimatePresence>
                  <motion.div
                    className="w-48 h-48 rounded-full bg-gradient-to-br from-primary/60 to-secondary/60 flex items-center justify-center shadow-2xl absolute"
                    animate={{ 
                      scale: isActive ? getCircleScale() : 1,
                      opacity: isActive ? [0.7, 1, 0.7] : 0.7
                    }}
                    transition={{ 
                      duration: isActive ? phaseDurations[currentPhase] : 0,
                      ease: "easeInOut",
                      repeat: 0
                    }}
                  >
                    <div className="text-white font-semibold text-xl">
                      {phaseInstructions[currentPhase]}
                    </div>
                  </motion.div>
                </AnimatePresence>
                
                {/* Inner highlight */}
                <motion.div 
                  className="w-32 h-32 rounded-full bg-white/30 absolute top-8 left-8"
                  animate={{ 
                    scale: isActive ? getCircleScale() : 1,
                    opacity: isActive ? [0.3, 0.6, 0.3] : 0.3
                  }}
                  transition={{ 
                    duration: isActive ? phaseDurations[currentPhase] : 0,
                    ease: "easeInOut",
                    delay: 0.2
                  }}
                />
              </div>
            </div>

            {/* Progress indicator */}
            <div className="mb-6">
              <div className="flex justify-between text-sm text-slate-600 mb-2">
                <span>Progress</span>
                <span>{currentCycle - 1}/{totalCycles} cycles</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-secondary to-green-500 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${progressPercentage}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col sm:flex-row gap-4">
          <Button 
            onClick={togglePause}
            variant="outline"
            className="flex-1 bg-white text-slate-700 font-semibold py-4 px-6 rounded-xl hover:shadow-lg transition-all duration-300 border-2 border-slate-200 h-auto"
          >
            {isActive ? <Pause className="mr-2 h-5 w-5" /> : <Play className="mr-2 h-5 w-5" />}
            {isActive ? "Pause" : "Resume"}
          </Button>
          
          <Button 
            onClick={handleComplete}
            className="flex-1 bg-gradient-to-r from-secondary to-green-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg hover:scale-105 transition-all duration-300 h-auto"
          >
            <Check className="mr-2 h-5 w-5" />
            Complete
          </Button>
        </div>
      </div>
    </div>
  );
}
