import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Target, Calendar, CheckCircle2, Plus, Trophy } from "lucide-react";

interface MoodGoal {
  id: number;
  targetMood: string;
  targetEmoji: string;
  description: string;
  targetDate: string;
  isCompleted: boolean;
}

interface MoodGoalsProps {
  userName: string;
  onBack: () => void;
}

const moodOptions = [
  { name: "Happy", emoji: "😊" },
  { name: "Calm", emoji: "😌" },
  { name: "Confident", emoji: "😎" },
  { name: "Grateful", emoji: "🙏" },
  { name: "Excited", emoji: "🤩" },
  { name: "Peaceful", emoji: "🕊️" },
];

export default function MoodGoals({ userName, onBack }: MoodGoalsProps) {
  const [goals, setGoals] = useState<MoodGoal[]>([
    {
      id: 1,
      targetMood: "Happy",
      targetEmoji: "😊",
      description: "Feel genuinely happy for 5 days this week",
      targetDate: "2025-01-31",
      isCompleted: false
    }
  ]);
  const [showForm, setShowForm] = useState(false);
  const [selectedMood, setSelectedMood] = useState(moodOptions[0]);
  const [description, setDescription] = useState("");
  const [targetDate, setTargetDate] = useState("");

  const handleCreateGoal = () => {
    if (!description.trim() || !targetDate) return;
    
    const newGoal: MoodGoal = {
      id: Date.now(),
      targetMood: selectedMood.name,
      targetEmoji: selectedMood.emoji,
      description: description.trim(),
      targetDate,
      isCompleted: false
    };
    
    setGoals(prev => [...prev, newGoal]);
    setDescription("");
    setTargetDate("");
    setShowForm(false);
  };

  const toggleGoalCompletion = (id: number) => {
    setGoals(prev => prev.map(goal => 
      goal.id === id ? { ...goal, isCompleted: !goal.isCompleted } : goal
    ));
  };

  const completedGoals = goals.filter(goal => goal.isCompleted);
  const activeGoals = goals.filter(goal => !goal.isCompleted);

  return (
    <div className="min-h-screen bg-slate-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <Card className="shadow-lg border-0 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center">
                <Target className="text-primary mr-3 h-8 w-8" />
                Mood Goals
              </h2>
              <p className="text-slate-600">Set and track your emotional wellness targets</p>
            </div>
            <Button onClick={onBack} variant="outline" className="rounded-xl">
              Back to Dashboard
            </Button>
          </div>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="p-4 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/20 rounded-lg">
                <Target className="h-5 w-5 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-800">{goals.length}</div>
                <div className="text-sm text-slate-600">Total Goals</div>
              </div>
            </div>
          </Card>
          
          <Card className="p-4 bg-gradient-to-br from-secondary/10 to-secondary/5 border-secondary/20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-secondary/20 rounded-lg">
                <CheckCircle2 className="h-5 w-5 text-secondary" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-800">{completedGoals.length}</div>
                <div className="text-sm text-slate-600">Completed</div>
              </div>
            </div>
          </Card>
          
          <Card className="p-4 bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-accent/20 rounded-lg">
                <Trophy className="h-5 w-5 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-800">
                  {goals.length > 0 ? Math.round((completedGoals.length / goals.length) * 100) : 0}%
                </div>
                <div className="text-sm text-slate-600">Success Rate</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Active Goals */}
        <Card className="shadow-lg border-0 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-slate-800">Active Goals</h3>
            <Button 
              onClick={() => setShowForm(!showForm)}
              className="bg-gradient-to-r from-primary to-indigo-600 text-white rounded-xl"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Goal
            </Button>
          </div>

          {showForm && (
            <div className="bg-slate-50 rounded-xl p-6 mb-6 border-2 border-dashed border-slate-300">
              <h4 className="font-semibold text-slate-700 mb-4">Create New Mood Goal</h4>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-slate-700 mb-2 block">Target Mood</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {moodOptions.map((mood) => (
                      <button
                        key={mood.name}
                        type="button"
                        onClick={() => setSelectedMood(mood)}
                        className={`p-3 border-2 rounded-xl transition-all text-center ${
                          selectedMood.name === mood.name 
                            ? 'border-primary bg-primary/5' 
                            : 'border-slate-200 hover:border-primary/50'
                        }`}
                      >
                        <div className="text-2xl mb-1">{mood.emoji}</div>
                        <div className="text-sm font-medium">{mood.name}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium text-slate-700 mb-2 block">Goal Description</Label>
                  <Textarea
                    placeholder="Describe your mood goal..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="border-2 border-slate-200 rounded-xl"
                    rows={2}
                  />
                </div>

                <div>
                  <Label className="text-sm font-medium text-slate-700 mb-2 block">Target Date</Label>
                  <Input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="border-2 border-slate-200 rounded-xl"
                  />
                </div>

                <div className="flex space-x-3">
                  <Button 
                    onClick={handleCreateGoal}
                    className="bg-secondary text-white rounded-xl"
                    disabled={!description.trim() || !targetDate}
                  >
                    Create Goal
                  </Button>
                  <Button 
                    onClick={() => setShowForm(false)}
                    variant="outline"
                    className="rounded-xl"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-4">
            {activeGoals.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <Target className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No active goals yet. Create one to start tracking your progress!</p>
              </div>
            ) : (
              activeGoals.map((goal) => (
                <div key={goal.id} className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-3xl">{goal.targetEmoji}</div>
                      <div className="flex-1">
                        <div className="font-medium text-slate-800">{goal.description}</div>
                        <div className="text-sm text-slate-500 flex items-center mt-1">
                          <Calendar className="h-4 w-4 mr-1" />
                          Target: {new Date(goal.targetDate).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => toggleGoalCompletion(goal.id)}
                      variant="outline"
                      className="rounded-xl border-secondary text-secondary hover:bg-secondary hover:text-white"
                    >
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Mark Complete
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Completed Goals */}
        {completedGoals.length > 0 && (
          <Card className="shadow-lg border-0 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
              <Trophy className="text-accent mr-2 h-5 w-5" />
              Completed Goals
            </h3>
            
            <div className="space-y-3">
              {completedGoals.map((goal) => (
                <div key={goal.id} className="bg-gradient-to-r from-secondary/10 to-green-50 border border-secondary/20 rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-2xl">{goal.targetEmoji}</div>
                      <div className="flex-1">
                        <div className="font-medium text-slate-800 line-through opacity-75">{goal.description}</div>
                        <div className="text-sm text-slate-500">Completed!</div>
                      </div>
                    </div>
                    <div className="text-secondary">
                      <CheckCircle2 className="h-6 w-6" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}