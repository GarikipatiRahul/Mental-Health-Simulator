import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Play } from "lucide-react";

interface WelcomeScreenProps {
  onStartSession: (name: string) => void;
}

export default function WelcomeScreen({ onStartSession }: WelcomeScreenProps) {
  const [name, setName] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onStartSession(name.trim());
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 animate-fade-in">
      <Card className="w-full max-w-md shadow-2xl shadow-primary/10 border-0 rounded-3xl">
        <CardContent className="p-8 text-center">
          <div className="mb-8">
            <img 
              src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300" 
              alt="Peaceful meditation scene" 
              className="rounded-2xl w-full h-48 object-cover shadow-lg"
            />
          </div>
          
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-800 mb-3 flex items-center justify-center">
              <Heart className="text-primary mr-3 h-8 w-8" />
              Mental Wellness Companion
            </h1>
            <p className="text-slate-600 text-lg leading-relaxed">
              Welcome to your personal mental health check-in. Let's start your journey toward emotional awareness and wellbeing.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="text-left">
              <Label htmlFor="userName" className="text-sm font-semibold text-slate-700 mb-3 block">
                What's your name?
              </Label>
              <Input
                type="text"
                id="userName"
                placeholder="Enter your name here..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-4 border-2 border-slate-200 rounded-xl focus:border-primary focus:ring-4 focus:ring-primary/20 transition-all duration-200 text-lg"
                required
              />
            </div>
            
            <Button 
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-indigo-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg hover:scale-105 transition-all duration-300 text-lg h-auto"
            >
              <Play className="mr-2 h-5 w-5" />
              Start Your Session
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
