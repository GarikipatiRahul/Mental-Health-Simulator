import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Wind, BarChart3, Quote } from "lucide-react";

interface QuoteScreenProps {
  onBreathingExercise: () => void;
  onDashboard: () => void;
}

export default function QuoteScreen({ onBreathingExercise, onDashboard }: QuoteScreenProps) {
  const { data: quote, isLoading } = useQuery({
    queryKey: ['/api/quote'],
    staleTime: 0, // Always fetch a new quote
  });

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl text-center shadow-2xl shadow-primary/10 border-0 rounded-3xl animate-fade-in">
        <CardContent className="p-8">
          <div className="mb-8">
            <Quote className="text-6xl text-primary/20 mb-6 mx-auto h-16 w-16" />
            
            {isLoading ? (
              <div className="space-y-4">
                <div className="h-8 bg-slate-200 rounded animate-pulse"></div>
                <div className="h-6 bg-slate-100 rounded animate-pulse w-2/3 mx-auto"></div>
              </div>
            ) : (
              <>
                <blockquote className="text-2xl md:text-3xl font-medium text-slate-800 leading-relaxed mb-6">
                  "{quote?.text || 'Loading...'}"
                </blockquote>
                <cite className="text-lg text-slate-600 font-medium">
                  - {quote?.author || 'Unknown'}
                </cite>
              </>
            )}
          </div>

          <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-2xl p-6 mb-8">
            <p className="text-slate-700 font-medium">
              Your mood has been logged! Remember, every feeling is valid and temporary. You're doing great by checking in with yourself.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              onClick={onBreathingExercise}
              className="flex-1 bg-gradient-to-r from-secondary to-green-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg hover:scale-105 transition-all duration-300 h-auto"
            >
              <Wind className="mr-2 h-5 w-5" />
              Try Breathing Exercise
            </Button>
            
            <Button 
              onClick={onDashboard}
              className="flex-1 bg-gradient-to-r from-primary to-indigo-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg hover:scale-105 transition-all duration-300 h-auto"
            >
              <BarChart3 className="mr-2 h-5 w-5" />
              View Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
