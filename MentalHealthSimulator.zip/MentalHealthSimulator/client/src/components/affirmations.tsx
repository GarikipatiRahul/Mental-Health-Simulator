import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, RefreshCw, Sparkles, Volume2, VolumeX } from "lucide-react";

interface AffirmationsProps {
  onBack: () => void;
}

interface Affirmation {
  text: string;
  category: string;
}

const categories = [
  { name: "all", label: "All", color: "bg-slate-100 text-slate-700" },
  { name: "self-love", label: "Self Love", color: "bg-pink-100 text-pink-700" },
  { name: "strength", label: "Strength", color: "bg-red-100 text-red-700" },
  { name: "anxiety", label: "Anxiety", color: "bg-blue-100 text-blue-700" },
  { name: "confidence", label: "Confidence", color: "bg-purple-100 text-purple-700" },
  { name: "growth", label: "Growth", color: "bg-green-100 text-green-700" },
  { name: "gratitude", label: "Gratitude", color: "bg-yellow-100 text-yellow-700" },
];

export default function Affirmations({ onBack }: AffirmationsProps) {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [currentAffirmation, setCurrentAffirmation] = useState<Affirmation | null>(null);
  const [isReading, setIsReading] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  const affirmations: Affirmation[] = [
    { text: "I am worthy of love and happiness", category: "self-love" },
    { text: "I have the strength to overcome any challenge", category: "strength" },
    { text: "I choose peace over worry", category: "anxiety" },
    { text: "I am grateful for all the good in my life", category: "gratitude" },
    { text: "I believe in my ability to figure things out", category: "confidence" },
    { text: "I am becoming the best version of myself", category: "growth" },
    { text: "I deserve to take up space in this world", category: "self-worth" },
    { text: "I trust the process of life", category: "trust" },
    { text: "I am resilient and can handle whatever comes my way", category: "strength" },
    { text: "I choose to focus on what I can control", category: "anxiety" },
    { text: "I am learning and growing every day", category: "growth" },
    { text: "I am enough, just as I am", category: "self-love" },
    { text: "I release what no longer serves me", category: "growth" },
    { text: "I attract positive energy into my life", category: "gratitude" },
    { text: "I am creating a life I love", category: "confidence" },
  ];

  const filteredAffirmations = selectedCategory === "all" 
    ? affirmations 
    : affirmations.filter(aff => aff.category === selectedCategory);

  const getRandomAffirmation = () => {
    const available = filteredAffirmations;
    if (available.length > 0) {
      const randomIndex = Math.floor(Math.random() * available.length);
      setCurrentAffirmation(available[randomIndex]);
    }
  };

  const readAffirmation = () => {
    if (!currentAffirmation) return;
    
    if ('speechSynthesis' in window) {
      if (isReading) {
        window.speechSynthesis.cancel();
        setIsReading(false);
      } else {
        const utterance = new SpeechSynthesisUtterance(currentAffirmation.text);
        utterance.rate = 0.8;
        utterance.pitch = 1;
        utterance.volume = 0.8;
        
        utterance.onstart = () => setIsReading(true);
        utterance.onend = () => setIsReading(false);
        utterance.onerror = () => setIsReading(false);
        
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  const toggleFavorite = (text: string) => {
    setFavorites(prev => 
      prev.includes(text) 
        ? prev.filter(fav => fav !== text)
        : [...prev, text]
    );
  };

  // Get random affirmation on first load
  useState(() => {
    if (affirmations.length > 0) {
      const randomIndex = Math.floor(Math.random() * affirmations.length);
      setCurrentAffirmation(affirmations[randomIndex]);
    }
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <Card className="shadow-lg border-0 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center">
                <Sparkles className="text-pink-500 mr-3 h-8 w-8" />
                Daily Affirmations
              </h2>
              <p className="text-slate-600">Positive thoughts to uplift your spirit</p>
            </div>
            <Button onClick={onBack} variant="outline" className="rounded-xl">
              Back to Dashboard
            </Button>
          </div>
        </Card>

        {/* Category Filter */}
        <Card className="shadow-lg border-0 rounded-2xl p-6 mb-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Choose a focus area:</h3>
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <Badge
                key={category.name}
                className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
                  selectedCategory === category.name 
                    ? 'bg-primary text-white' 
                    : category.color
                }`}
                onClick={() => setSelectedCategory(category.name)}
              >
                {category.label}
              </Badge>
            ))}
          </div>
        </Card>

        {/* Main Affirmation Display */}
        <Card className="shadow-2xl border-0 rounded-3xl p-8 mb-6 bg-gradient-to-br from-white to-pink-50">
          <div className="text-center">
            <div className="mb-6">
              <Sparkles className="text-6xl text-pink-400 mx-auto h-16 w-16 animate-pulse" />
            </div>
            
            {currentAffirmation ? (
              <>
                <blockquote className="text-3xl md:text-4xl font-medium text-slate-800 leading-relaxed mb-6 min-h-32 flex items-center justify-center">
                  "{currentAffirmation.text}"
                </blockquote>
                
                <div className="flex items-center justify-center space-x-2 mb-8">
                  <Badge variant="secondary" className="bg-pink-100 text-pink-700">
                    #{currentAffirmation.category}
                  </Badge>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => toggleFavorite(currentAffirmation.text)}
                    className={`rounded-full ${
                      favorites.includes(currentAffirmation.text) 
                        ? 'text-red-500 hover:text-red-600' 
                        : 'text-gray-400 hover:text-red-500'
                    }`}
                  >
                    <Heart className={`h-5 w-5 ${
                      favorites.includes(currentAffirmation.text) ? 'fill-current' : ''
                    }`} />
                  </Button>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    onClick={getRandomAffirmation}
                    className="bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold py-3 px-8 rounded-xl hover:shadow-lg hover:scale-105 transition-all duration-300"
                  >
                    <RefreshCw className="mr-2 h-5 w-5" />
                    New Affirmation
                  </Button>
                  
                  {('speechSynthesis' in window) && (
                    <Button 
                      onClick={readAffirmation}
                      variant="outline"
                      className="font-semibold py-3 px-8 rounded-xl hover:shadow-lg transition-all duration-300"
                    >
                      {isReading ? (
                        <>
                          <VolumeX className="mr-2 h-5 w-5" />
                          Stop Reading
                        </>
                      ) : (
                        <>
                          <Volume2 className="mr-2 h-5 w-5" />
                          Read Aloud
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <div className="text-slate-400 mb-4">Loading affirmation...</div>
                <Button onClick={getRandomAffirmation} className="bg-primary text-white rounded-xl">
                  Get Affirmation
                </Button>
              </div>
            )}
          </div>
        </Card>

        {/* Favorites Section */}
        {favorites.length > 0 && (
          <Card className="shadow-lg border-0 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
              <Heart className="text-red-500 mr-2 h-5 w-5 fill-current" />
              Your Favorite Affirmations
            </h3>
            
            <div className="grid gap-4">
              {favorites.map((favorite, index) => (
                <div key={index} className="bg-gradient-to-r from-pink-50 to-purple-50 border border-pink-200 rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <p className="text-slate-700 italic">"{favorite}"</p>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => toggleFavorite(favorite)}
                      className="text-red-500 hover:text-red-600 rounded-full"
                    >
                      <Heart className="h-4 w-4 fill-current" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Daily Practice Tips */}
        <Card className="shadow-lg border-0 rounded-2xl p-6 mt-6">
          <h3 className="text-xl font-bold text-slate-800 mb-4">💫 Daily Practice Tips</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-4 rounded-xl">
              <h4 className="font-semibold text-slate-800 mb-2">Morning Ritual</h4>
              <p className="text-sm text-slate-600">Start your day with 3 affirmations. Repeat them while looking in the mirror.</p>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-xl">
              <h4 className="font-semibold text-slate-800 mb-2">Mindful Repetition</h4>
              <p className="text-sm text-slate-600">Say each affirmation slowly and really feel the words resonate within you.</p>
            </div>
            <div className="bg-gradient-to-br from-yellow-50 to-amber-50 p-4 rounded-xl">
              <h4 className="font-semibold text-slate-800 mb-2">Write It Down</h4>
              <p className="text-sm text-slate-600">Keep a journal of your favorite affirmations and how they make you feel.</p>
            </div>
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-4 rounded-xl">
              <h4 className="font-semibold text-slate-800 mb-2">Believe & Receive</h4>
              <p className="text-sm text-slate-600">Focus on truly believing the words. Your subconscious mind is listening.</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}