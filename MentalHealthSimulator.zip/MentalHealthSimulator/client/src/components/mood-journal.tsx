import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Plus, Tag, Calendar, Search, Edit, Trash2 } from "lucide-react";

interface JournalEntry {
  id: number;
  title: string;
  content: string;
  tags: string[];
  timestamp: Date;
}

interface MoodJournalProps {
  userName: string;
  onBack: () => void;
}

export default function MoodJournal({ userName, onBack }: MoodJournalProps) {
  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: 1,
      title: "Feeling grateful today",
      content: "Had a wonderful morning walk. The fresh air really helped clear my mind and I felt so grateful for my health and the beautiful nature around me. Sometimes it's the simple things that bring the most joy.",
      tags: ["gratitude", "nature", "morning"],
      timestamp: new Date()
    }
  ]);
  
  const [showForm, setShowForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [currentTag, setCurrentTag] = useState("");
  const [tags, setTags] = useState<string[]>([]);

  const resetForm = () => {
    setTitle("");
    setContent("");
    setTags([]);
    setCurrentTag("");
    setEditingEntry(null);
  };

  const handleCreateEntry = () => {
    if (!title.trim() || !content.trim()) return;

    const newEntry: JournalEntry = {
      id: editingEntry ? editingEntry.id : Date.now(),
      title: title.trim(),
      content: content.trim(),
      tags: [...tags],
      timestamp: editingEntry ? editingEntry.timestamp : new Date()
    };

    if (editingEntry) {
      setEntries(prev => prev.map(entry => 
        entry.id === editingEntry.id ? newEntry : entry
      ));
    } else {
      setEntries(prev => [newEntry, ...prev]);
    }

    resetForm();
    setShowForm(false);
  };

  const handleEditEntry = (entry: JournalEntry) => {
    setEditingEntry(entry);
    setTitle(entry.title);
    setContent(entry.content);
    setTags([...entry.tags]);
    setShowForm(true);
  };

  const handleDeleteEntry = (id: number) => {
    setEntries(prev => prev.filter(entry => entry.id !== id));
  };

  const addTag = () => {
    if (currentTag.trim() && !tags.includes(currentTag.trim())) {
      setTags(prev => [...prev, currentTag.trim()]);
      setCurrentTag("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(prev => prev.filter(tag => tag !== tagToRemove));
  };

  const filteredEntries = entries.filter(entry =>
    entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    entry.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-slate-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <Card className="shadow-lg border-0 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center">
                <BookOpen className="text-primary mr-3 h-8 w-8" />
                Mood Journal
              </h2>
              <p className="text-slate-600">Capture your thoughts and emotions</p>
            </div>
            <Button onClick={onBack} variant="outline" className="rounded-xl">
              Back to Dashboard
            </Button>
          </div>
        </Card>

        {/* Search and Add */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Input
              placeholder="Search journal entries..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-2 border-slate-200 rounded-xl focus:border-primary"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
          </div>
          <Button 
            onClick={() => setShowForm(!showForm)}
            className="bg-gradient-to-r from-primary to-indigo-600 text-white rounded-xl"
          >
            <Plus className="mr-2 h-4 w-4" />
            {editingEntry ? "Edit Entry" : "New Entry"}
          </Button>
        </div>

        {/* Entry Form */}
        {showForm && (
          <Card className="shadow-lg border-0 rounded-2xl p-6 mb-6">
            <h3 className="text-xl font-bold text-slate-800 mb-4">
              {editingEntry ? "Edit Journal Entry" : "New Journal Entry"}
            </h3>
            
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-slate-700 mb-2 block">Title</Label>
                <Input
                  placeholder="Give your entry a title..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="border-2 border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <Label className="text-sm font-medium text-slate-700 mb-2 block">Content</Label>
                <Textarea
                  placeholder="Write about your thoughts and feelings..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="border-2 border-slate-200 rounded-xl min-h-32"
                  rows={6}
                />
              </div>

              <div>
                <Label className="text-sm font-medium text-slate-700 mb-2 block">Tags</Label>
                <div className="flex space-x-2 mb-2">
                  <Input
                    placeholder="Add a tag..."
                    value={currentTag}
                    onChange={(e) => setCurrentTag(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                    className="flex-1 border-2 border-slate-200 rounded-xl"
                  />
                  <Button onClick={addTag} variant="outline" className="rounded-xl">
                    <Tag className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {tags.map((tag) => (
                    <Badge 
                      key={tag} 
                      variant="secondary" 
                      className="bg-primary/10 text-primary hover:bg-primary/20 cursor-pointer"
                      onClick={() => removeTag(tag)}
                    >
                      {tag} ×
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex space-x-3">
                <Button 
                  onClick={handleCreateEntry}
                  className="bg-secondary text-white rounded-xl"
                  disabled={!title.trim() || !content.trim()}
                >
                  {editingEntry ? "Update Entry" : "Save Entry"}
                </Button>
                <Button 
                  onClick={() => {
                    resetForm();
                    setShowForm(false);
                  }}
                  variant="outline"
                  className="rounded-xl"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Journal Entries */}
        <div className="space-y-4">
          {filteredEntries.length === 0 ? (
            <Card className="shadow-lg border-0 rounded-2xl p-12 text-center">
              <BookOpen className="h-16 w-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-xl font-medium text-slate-600 mb-2">
                {searchQuery ? "No entries match your search" : "No journal entries yet"}
              </h3>
              <p className="text-slate-500 mb-6">
                {searchQuery 
                  ? "Try different keywords or clear your search" 
                  : "Start writing to capture your thoughts and feelings"
                }
              </p>
              {!searchQuery && (
                <Button 
                  onClick={() => setShowForm(true)}
                  className="bg-gradient-to-r from-primary to-indigo-600 text-white rounded-xl"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Write Your First Entry
                </Button>
              )}
            </Card>
          ) : (
            filteredEntries.map((entry) => (
              <Card key={entry.id} className="shadow-lg border-0 rounded-2xl p-6 hover:shadow-xl transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-xl font-bold text-slate-800">{entry.title}</h3>
                  <div className="flex space-x-2">
                    <Button 
                      onClick={() => handleEditEntry(entry)}
                      variant="outline"
                      size="sm"
                      className="rounded-lg"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      onClick={() => handleDeleteEntry(entry.id)}
                      variant="outline"
                      size="sm"
                      className="rounded-lg text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <p className="text-slate-700 leading-relaxed mb-4">{entry.content}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-2">
                    {entry.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-primary/10 text-primary">
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                  <div className="text-sm text-slate-500 flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {entry.timestamp.toLocaleDateString()}
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}