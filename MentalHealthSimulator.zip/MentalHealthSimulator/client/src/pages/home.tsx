import { useState } from "react";
import WelcomeScreen from "@/components/welcome-screen";
import MoodLogging from "@/components/mood-logging";
import QuoteScreen from "@/components/quote-screen";
import BreathingExercise from "@/components/breathing-exercise";
import Dashboard from "@/components/dashboard";
import MoodGoals from "@/components/mood-goals";
import MoodJournal from "@/components/mood-journal";
import MoodStreaks from "@/components/mood-streaks";
import Affirmations from "@/components/affirmations";

type Screen = "welcome" | "moodLogging" | "quote" | "breathing" | "dashboard" | "goals" | "journal" | "streaks" | "affirmations";

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("welcome");
  const [userName, setUserName] = useState("");
  const [currentMood, setCurrentMood] = useState<{mood: string, emoji: string, notes?: string} | null>(null);

  const handleStartSession = (name: string) => {
    setUserName(name);
    setCurrentScreen("moodLogging");
  };

  const handleMoodLogged = (mood: string, emoji: string, notes?: string) => {
    setCurrentMood({ mood, emoji, notes });
    setCurrentScreen("quote");
  };

  const handleRestartSession = () => {
    setUserName("");
    setCurrentMood(null);
    setCurrentScreen("welcome");
  };

  return (
    <>
      {currentScreen === "welcome" && (
        <WelcomeScreen onStartSession={handleStartSession} />
      )}
      
      {currentScreen === "moodLogging" && (
        <MoodLogging 
          userName={userName}
          onMoodLogged={handleMoodLogged}
        />
      )}
      
      {currentScreen === "quote" && (
        <QuoteScreen 
          onBreathingExercise={() => setCurrentScreen("breathing")}
          onDashboard={() => setCurrentScreen("dashboard")}
        />
      )}
      
      {currentScreen === "breathing" && (
        <BreathingExercise 
          onComplete={() => setCurrentScreen("dashboard")}
        />
      )}
      
      {currentScreen === "dashboard" && (
        <Dashboard 
          userName={userName}
          onRestartSession={handleRestartSession}
          onBreathingExercise={() => setCurrentScreen("breathing")}
          onLogNewMood={() => setCurrentScreen("moodLogging")}
          onMoodGoals={() => setCurrentScreen("goals")}
          onMoodJournal={() => setCurrentScreen("journal")}
          onMoodStreaks={() => setCurrentScreen("streaks")}
          onAffirmations={() => setCurrentScreen("affirmations")}
        />
      )}
      
      {currentScreen === "goals" && (
        <MoodGoals 
          userName={userName}
          onBack={() => setCurrentScreen("dashboard")}
        />
      )}
      
      {currentScreen === "journal" && (
        <MoodJournal 
          userName={userName}
          onBack={() => setCurrentScreen("dashboard")}
        />
      )}
      
      {currentScreen === "streaks" && (
        <MoodStreaks 
          userName={userName}
          onBack={() => setCurrentScreen("dashboard")}
        />
      )}
      
      {currentScreen === "affirmations" && (
        <Affirmations 
          onBack={() => setCurrentScreen("dashboard")}
        />
      )}
    </>
  );
}
