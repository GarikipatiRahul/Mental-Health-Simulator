# 🧠 Mental Wellness Companion

A comprehensive full-stack mental health application that provides mood tracking, motivational content, wellness tools, and mindfulness exercises. Built with modern web technologies to support your emotional wellness journey.

## ✨ Features

### Core Functionality
- 🏠 **Welcome Screen** - Personalized user onboarding
- 😊 **Mood Logging** - Track emotions with intuitive emoji interface
- 💬 **Motivational Quotes** - Inspiring messages to uplift your day
- 🫁 **Breathing Exercises** - Guided meditation with visual animations
- 📊 **Analytics Dashboard** - Comprehensive mood data visualization

### Advanced Wellness Tools
- 🎯 **Mood Goals** - Set and track emotional wellness targets
- 📝 **Mood Journal** - Write detailed thoughts with tagging system
- 🔥 **Mood Streaks** - Track daily check-in consistency with achievements
- ✨ **Daily Affirmations** - Positive mindset reinforcement with text-to-speech

### Data Structure Demonstrations
- 📈 **Mood Frequency** (Map) - Visual frequency analysis
- ⏰ **Recent Moods** (Queue) - Last 5 mood entries
- 💎 **Unique Moods** (Set) - Distinct emotional states
- 🔍 **Mood Search** (Find) - Search through mood history

### C++ Data Structure Implementations
- 🖥️ **Educational C++ Code** - Complete implementations of all data structures
- 🎮 **Interactive Demo** - Command-line program with menu-driven interface
- 📚 **Learning Resource** - Header files, source code, and comprehensive documentation
- 🔬 **Algorithm Analysis** - Performance comparisons and complexity explanations

## 🚀 Getting Started

### Prerequisites
- Node.js 20+
- PostgreSQL database
- Modern web browser
- C++17 compatible compiler (for data structure demos)

### Web Application Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd mental-wellness-companion
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create a `.env` file with:
   ```env
   DATABASE_URL=your_postgresql_connection_string
   NODE_ENV=development
   ```

4. **Initialize the database**
   ```bash
   npm run db:push
   ```

5. **Start the development server**
   ```bash
   npm run dev
   ```

6. **Open your browser**
   Navigate to `http://localhost:5000`

### C++ Data Structures Demo

1. **Navigate to C++ directory**
   ```bash
   cd cpp-datastructures
   ```

2. **Compile and run**
   ```bash
   ./compile_and_run.sh
   ```

3. **Explore interactive demo**
   - Use the menu system to interact with data structures
   - See real-time demonstrations of algorithms
   - Learn how each structure applies to mental health tracking

## 🏗️ Architecture

### Frontend
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: shadcn/ui built on Radix UI primitives
- **Styling**: Tailwind CSS with custom wellness color palette
- **State Management**: TanStack Query for server state
- **Animations**: Framer Motion for breathing exercises

### Backend
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Neon Database serverless
- **ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful endpoints with Zod validation

### Database Schema
```sql
users (id, username, password)
mood_entries (id, user_id, mood, emoji, notes, timestamp)
journal_entries (id, user_id, title, content, tags[], timestamp)
mood_goals (id, user_id, target_mood, target_emoji, description, target_date, is_completed, timestamp)
user_streaks (id, user_id, current_streak, longest_streak, last_check_in)
```

## 📱 User Journey

1. **Welcome** → Enter your name to start a session
2. **Mood Check** → Select current emotion and add optional notes
3. **Motivation** → Receive an inspirational quote
4. **Mindfulness** → Optional guided breathing exercise
5. **Analytics** → View mood data and patterns
6. **Tools** → Access goals, journal, streaks, and affirmations

## 🎨 Design Philosophy

### Wellness-First Design
- Calming color palette with blues, greens, and purples
- Gentle animations and transitions
- Accessible typography and contrast ratios
- Mobile-responsive design for on-the-go wellness

### Data Structure Education
- Visual demonstrations of fundamental data structures
- Real-world applications in mood tracking context
- Interactive examples showing Map, Queue, Set, and Search operations

## 🔧 Development

### Available Scripts

```bash
# Start development server
npm run dev

# Push database schema changes
npm run db:push

# Build for production
npm run build

# Start production server
npm start
```

### Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Application pages
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utility functions
├── server/                 # Backend Express application
│   ├── data/              # Static data (quotes, affirmations)
│   ├── routes.ts          # API endpoints
│   ├── storage.ts         # Database operations
│   └── db.ts              # Database configuration
├── shared/                # Shared types and schemas
│   └── schema.ts          # Drizzle database schema
├── cpp-datastructures/    # C++ educational implementations
│   ├── mood_tracker.hpp   # Header file with class declarations
│   ├── mood_tracker.cpp   # Core data structure implementations
│   ├── main.cpp          # Interactive demo program
│   ├── compile_and_run.sh # Build and execution script
│   └── README.md         # C++ documentation
└── README.md             # Main project documentation
```

## 🛠️ API Endpoints

### Core Endpoints
- `GET /api/session/:name` - Retrieve user session data
- `POST /api/moods` - Log new mood entries
- `GET /api/quote` - Fetch random motivational quotes
- `GET /api/export/:name` - Export user mood data

### Future Endpoints (Ready for Implementation)
- `POST /api/journal` - Create journal entries
- `GET /api/journal/:userId` - Get user journal entries
- `POST /api/goals` - Create mood goals
- `GET /api/goals/:userId` - Get user mood goals
- `PUT /api/goals/:id` - Update mood goal status
- `GET /api/streaks/:userId` - Get user streak data
- `PUT /api/streaks/:userId` - Update user streak

## 🎯 Features Breakdown

### Mood Logging
- 6 predefined emotional states with emojis
- Optional notes for detailed context
- Real-time validation and feedback
- Automatic timestamp tracking

### Analytics Dashboard
- **Mood History**: Complete chronological log
- **Frequency Analysis**: Visual bar charts showing mood patterns
- **Recent Activity**: Queue-based display of last 5 moods
- **Unique Emotions**: Set-based collection of distinct moods
- **Search Functionality**: Filter by mood type or notes

### Breathing Exercise
- Guided 4-4-4-2 breathing pattern (Inhale-Hold-Exhale-Rest)
- Visual animation with scaling circle
- 10-cycle completion with progress tracking
- Pause/resume functionality
- Calming color scheme and transitions

### Mood Goals
- Set target emotional states with deadlines
- Track completion progress with statistics
- Visual progress indicators
- Achievement celebration

### Mood Journal
- Rich text entries with titles
- Tagging system for categorization
- Search through entries
- Edit and delete functionality
- Timestamp tracking

### Mood Streaks
- Daily check-in consistency tracking
- Achievement levels (Starting → Building → Committed → Expert → Master)
- Weekly and monthly progress goals
- Positive mood streak tracking
- Motivational messaging

### Daily Affirmations
- 15+ curated positive affirmations
- Category-based filtering (self-love, strength, anxiety, etc.)
- Text-to-speech functionality
- Favorite affirmations system
- Daily practice tips

## 🌟 Key Benefits

### For Users
- **Emotional Awareness**: Regular mood check-ins promote self-reflection
- **Pattern Recognition**: Visual analytics reveal emotional trends
- **Mindfulness Practice**: Guided breathing exercises reduce stress
- **Goal Achievement**: Structured approach to emotional wellness
- **Positive Mindset**: Daily affirmations reinforce self-worth

### For Developers
- **Modern Stack**: Latest React, TypeScript, and database technologies
- **Type Safety**: Full-stack TypeScript with Drizzle ORM
- **Scalable Architecture**: Clean separation of concerns
- **Educational Value**: Real-world data structure implementations
- **Production Ready**: PostgreSQL database with proper error handling

## 🔒 Privacy & Security

- Local session management for demo purposes
- No personal data collection beyond mood entries
- Secure database connections with environment variables
- Optional data export for user control
- Client-side form validation with server-side verification

## 🚀 Future Enhancements

### Short Term
- [ ] User authentication system
- [ ] Data export/import functionality
- [ ] Additional breathing exercise patterns
- [ ] Customizable mood categories
- [ ] Dark mode support

### Long Term
- [ ] Social features for sharing progress
- [ ] AI-powered mood insights
- [ ] Integration with wearable devices
- [ ] Therapist collaboration tools
- [ ] Mobile app development

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **shadcn/ui** for beautiful, accessible components
- **Radix UI** for robust primitive components
- **Tailwind CSS** for utility-first styling
- **Drizzle ORM** for type-safe database operations
- **Mental health community** for inspiration and guidance

## 📞 Support

If you're experiencing mental health challenges, please reach out to:
- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741
- Mental Health America: [mhanational.org](https://mhanational.org)

Remember: This app is a wellness tool, not a replacement for professional mental health care.

---

**Built with ❤️ for mental wellness**