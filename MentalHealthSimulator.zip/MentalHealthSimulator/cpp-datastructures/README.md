# 🧠 Mental Wellness C++ Data Structures

This directory contains C++ implementations of the core data structures used in the Mental Wellness Companion web application. These implementations demonstrate how fundamental computer science concepts apply to real-world mental health tracking and analytics.

## 📚 Data Structures Implemented

### 1. **Array/Vector** - Complete Mood History
- **Purpose**: Store all mood entries in chronological order
- **Operations**: Push back, random access, size tracking
- **Use Case**: Complete mood timeline and historical analysis
- **Complexity**: O(1) access, O(1) amortized insertion

### 2. **Map** - Mood Frequency Analysis
- **Purpose**: Count frequency of each mood type
- **Operations**: Insert/update counts, lookup frequency, find most common
- **Use Case**: Statistical analysis and pattern recognition
- **Complexity**: O(log n) operations (Red-Black Tree implementation)

### 3. **Queue (FIFO)** - Recent Moods Tracking
- **Purpose**: Maintain sliding window of last 5 mood entries
- **Operations**: Push (add new), pop (remove oldest), front access
- **Use Case**: "Recent Activity" display and trend analysis
- **Complexity**: O(1) for all operations

### 4. **Set** - Unique Moods Collection
- **Purpose**: Track distinct emotional states experienced
- **Operations**: Insert mood, check existence, count unique
- **Use Case**: Emotional vocabulary expansion and diversity metrics
- **Complexity**: O(log n) operations (Red-Black Tree implementation)

### 5. **Stack (LIFO)** - Goal Management
- **Purpose**: Manage mood improvement goals in priority order
- **Operations**: Push (add goal), pop (complete goal), peek (view top)
- **Use Case**: Goal-oriented therapy and achievement tracking
- **Complexity**: O(1) for all operations

### 6. **Linked List** - Journal Entries
- **Purpose**: Dynamic storage for written reflections and thoughts
- **Operations**: Insert at head, delete by ID, search by tag/keyword
- **Use Case**: Therapeutic journaling and content management
- **Complexity**: O(1) insertion, O(n) search and deletion

## 🚀 Getting Started

### Prerequisites
- C++17 compatible compiler (g++, clang++, MSVC)
- Standard Template Library (STL)
- Unix-like environment (Linux, macOS, WSL) for bash script

### Compilation and Execution

#### Option 1: Using the Provided Script
```bash
cd cpp-datastructures
./compile_and_run.sh
```

#### Option 2: Manual Compilation
```bash
cd cpp-datastructures
mkdir -p bin
g++ -std=c++17 -Wall -Wextra -O2 -o bin/mood_tracker main.cpp mood_tracker.cpp
./bin/mood_tracker
```

#### Option 3: Individual File Testing
```bash
g++ -std=c++17 -I. -c mood_tracker.cpp
g++ -std=c++17 -I. -c main.cpp
g++ -o mood_tracker main.o mood_tracker.o
./mood_tracker
```

## 🎮 Interactive Demo Features

The compiled program provides an interactive menu system with the following options:

### 1. **Add Mood Entry** 📊
- Demonstrates: Array/Vector, Map, Queue, Set operations simultaneously
- Input: Mood type, emoji, optional notes
- Shows: How one action updates multiple data structures

### 2. **View Mood Statistics** 📈
- Demonstrates: Complete data structure analysis
- Output: Frequency charts, recent activity, unique moods, search results

### 3. **Add Mood Goal** 🎯
- Demonstrates: Stack push operations
- Input: Target mood, goal description
- Shows: LIFO (Last In, First Out) principle

### 4. **Complete Goal** ✅
- Demonstrates: Stack pop operations
- Action: Remove and complete top goal
- Shows: Goal completion tracking

### 5. **View Goals Stack** 📚
- Demonstrates: Stack traversal without modification
- Output: Current goals in LIFO order, completed goals count

### 6. **Add Journal Entry** 📝
- Demonstrates: Linked list insertion at head
- Input: Title, content, optional tags
- Shows: Dynamic memory allocation

### 7. **View Journal Entries** 🔍
- Demonstrates: Linked list traversal
- Output: All entries with timestamps and tags

### 8. **Search Journal by Tag** 🏷️
- Demonstrates: Linked list search operations
- Input: Tag to search for
- Shows: Filtering and result collection

### 9. **Comprehensive Demo** 🎓
- Demonstrates: All data structures with educational explanations
- Shows: Complete system overview and complexity analysis

## 📁 File Structure

```
cpp-datastructures/
├── mood_tracker.hpp     # Header file with class declarations
├── mood_tracker.cpp     # Implementation of all data structures
├── main.cpp            # Interactive demo program
├── compile_and_run.sh  # Compilation and execution script
├── README.md          # This documentation
└── bin/               # Compiled executables (created during build)
```

## 🏗️ Class Architecture

### **MoodTracker Class**
```cpp
class MoodTracker {
private:
    std::vector<MoodEntry> moodHistory;        // Array/Vector
    std::map<std::string, int> moodFrequency;  // Map
    std::queue<MoodEntry> recentMoodsQueue;    // Queue
    std::set<std::string> uniqueMoods;         // Set
    
public:
    // Array/Vector operations
    void addMoodEntry(const std::string& mood, const std::string& emoji, const std::string& notes = "");
    std::vector<MoodEntry> getMoodHistory() const;
    
    // Map operations
    std::map<std::string, int> getMoodFrequency() const;
    std::string getMostFrequentMood() const;
    
    // Queue operations
    std::queue<MoodEntry> getRecentMoods() const;
    MoodEntry getLastMood() const;
    
    // Set operations
    std::set<std::string> getUniqueMoods() const;
    bool hasMood(const std::string& mood) const;
    
    // Search operations
    std::vector<MoodEntry> searchMoods(const std::string& searchTerm) const;
};
```

### **GoalTracker Class**
```cpp
class GoalTracker {
private:
    std::stack<MoodGoal> goalStack;           // Stack (LIFO)
    std::vector<MoodGoal> completedGoals;     // Completed goals storage
    
public:
    void pushGoal(const std::string& mood, const std::string& description);
    MoodGoal popGoal();
    MoodGoal peekTopGoal() const;
    void completeTopGoal();
};
```

### **JournalLinkedList Class**
```cpp
class JournalLinkedList {
private:
    JournalNode* head;                        // Linked List head pointer
    
public:
    void addEntry(const std::string& title, const std::string& content);
    JournalNode* findEntry(int id) const;
    void deleteEntry(int id);
    std::vector<JournalNode*> searchByTag(const std::string& tag) const;
};
```

## 🔬 Educational Value

### **Learning Objectives**
1. **Practical Application**: See how abstract data structures solve real problems
2. **Complexity Analysis**: Understand time and space trade-offs
3. **Memory Management**: Learn dynamic allocation in linked structures
4. **Algorithm Design**: Implement search, insertion, and deletion operations
5. **Problem Solving**: Map mental health needs to appropriate data structures

### **Key Concepts Demonstrated**
- **FIFO vs LIFO**: Queue (recent moods) vs Stack (goals)
- **Ordered vs Unordered**: Map (frequency) vs Set (uniqueness)
- **Sequential vs Linked**: Vector (history) vs Linked List (journal)
- **Search Strategies**: Linear search, key-based lookup, tag filtering
- **Memory Models**: Stack allocation vs heap allocation

## 🎯 Integration with Web Application

This C++ implementation mirrors the data structure usage in the web application:

### **Web App (JavaScript/TypeScript)** ↔ **C++ Implementation**
- `Array<MoodEntry>` ↔ `std::vector<MoodEntry>`
- `Map<string, number>` ↔ `std::map<std::string, int>`
- `Queue<MoodEntry>` ↔ `std::queue<MoodEntry>`
- `Set<string>` ↔ `std::set<std::string>`
- Goal management ↔ `std::stack<MoodGoal>`
- Journal entries ↔ `JournalNode* linked list`

### **Parallel Features**
1. **Mood Analytics**: Both implement frequency analysis and recent activity tracking
2. **Goal Management**: Stack-based priority system in both versions
3. **Search Functionality**: Text-based filtering in mood history and journal
4. **Data Persistence**: Web app uses PostgreSQL, C++ uses in-memory structures

## 💡 Usage Examples

### **Basic Mood Tracking**
```cpp
MoodTracker tracker;
tracker.addMoodEntry("Happy", "😊", "Great morning workout!");
tracker.addMoodEntry("Calm", "😌", "Meditation session was peaceful");

// View statistics
tracker.demonstrateDataStructures();
```

### **Goal Management**
```cpp
GoalTracker goals;
goals.pushGoal("Grateful", "Write 3 things I'm grateful for daily");
goals.pushGoal("Calm", "Practice deep breathing when anxious");

// Complete top goal
goals.completeTopGoal();
```

### **Journal Management**
```cpp
JournalLinkedList journal;
journal.addEntry("Mindfulness Journey", "Started meditation practice today...");
journal.addTag(1, "meditation");
journal.addTag(1, "mindfulness");

// Search by tag
auto results = journal.searchByTag("meditation");
```

## 🎓 Educational Extensions

### **Advanced Exercises**
1. **Binary Search Tree**: Implement for faster mood lookup by timestamp
2. **Hash Table**: Create custom hash map for O(1) mood frequency updates
3. **Priority Queue**: Use for mood goals with importance levels
4. **Graph Structures**: Model mood transitions and patterns
5. **Tree Traversals**: Implement mood categorization hierarchies

### **Performance Analysis**
1. **Benchmarking**: Compare operation times with different data sizes
2. **Memory Usage**: Analyze space complexity of each structure
3. **Cache Performance**: Study locality of reference in different operations
4. **Scalability**: Test with thousands of mood entries

## 🔍 Debugging and Development

### **Common Issues**
1. **Memory Leaks**: Ensure proper linked list node deletion
2. **Stack Overflow**: Check for infinite recursion in recursive functions
3. **Iterator Invalidation**: Be careful when modifying containers during iteration
4. **Boundary Conditions**: Handle empty containers gracefully

### **Development Tips**
1. **Use Valgrind**: Check for memory leaks and errors
2. **Enable Compiler Warnings**: Use `-Wall -Wextra` for better code quality
3. **Add Assertions**: Validate preconditions and postconditions
4. **Unit Testing**: Create test cases for each data structure operation

## 📊 Performance Characteristics

| Operation | Vector | Map | Queue | Set | Stack | Linked List |
|-----------|--------|-----|-------|-----|-------|-------------|
| Insert | O(1)* | O(log n) | O(1) | O(log n) | O(1) | O(1) |
| Search | O(n) | O(log n) | O(n) | O(log n) | O(n) | O(n) |
| Delete | O(n) | O(log n) | O(1) | O(log n) | O(1) | O(n) |
| Access | O(1) | O(log n) | O(1)† | O(log n) | O(1)† | O(n) |

*Amortized time complexity  
†Only front/top element access

## 🌟 Real-World Applications

### **Mental Health Technology**
- **Therapy Apps**: Mood tracking and progress visualization
- **Research Studies**: Data collection and statistical analysis
- **Clinical Tools**: Patient monitoring and intervention timing
- **Wellness Platforms**: Habit tracking and goal achievement

### **Data Structure Applications**
- **Social Media**: News feed algorithms (queues), friend suggestions (graphs)
- **E-commerce**: Shopping cart (stack), product recommendations (maps)
- **Gaming**: Leaderboards (priority queues), inventory systems (arrays)
- **Operating Systems**: Process scheduling (queues), memory management (linked lists)

---

**Built with 💙 for education and mental wellness**

*This C++ implementation serves as both a practical mental health tool and an educational resource for understanding fundamental data structures in computer science.*