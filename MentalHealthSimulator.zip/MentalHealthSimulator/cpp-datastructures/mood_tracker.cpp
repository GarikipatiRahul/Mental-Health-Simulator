#include "mood_tracker.hpp"
#include <iomanip>
#include <sstream>

// ========================
// MoodTracker Implementation
// ========================

void MoodTracker::addMoodEntry(const std::string& mood, const std::string& emoji, 
                               const std::string& notes) {
    MoodEntry entry(nextId++, mood, emoji, notes);
    
    // Array/Vector: Add to complete history
    moodHistory.push_back(entry);
    
    // Map: Update frequency count
    moodFrequency[mood]++;
    
    // Queue: Manage recent moods (keep only last 5)
    recentMoodsQueue.push(entry);
    if (recentMoodsQueue.size() > MAX_RECENT_MOODS) {
        recentMoodsQueue.pop();
    }
    
    // Set: Add to unique moods
    uniqueMoods.insert(mood);
    
    std::cout << "✓ Added mood: " << emoji << " " << mood << std::endl;
}

std::vector<MoodEntry> MoodTracker::getMoodHistory() const {
    return moodHistory;
}

size_t MoodTracker::getTotalMoodCount() const {
    return moodHistory.size();
}

std::map<std::string, int> MoodTracker::getMoodFrequency() const {
    return moodFrequency;
}

std::string MoodTracker::getMostFrequentMood() const {
    if (moodFrequency.empty()) return "";
    
    auto maxElement = std::max_element(moodFrequency.begin(), moodFrequency.end(),
        [](const std::pair<std::string, int>& a, const std::pair<std::string, int>& b) {
            return a.second < b.second;
        });
    
    return maxElement->first;
}

int MoodTracker::getMoodCount(const std::string& mood) const {
    auto it = moodFrequency.find(mood);
    return (it != moodFrequency.end()) ? it->second : 0;
}

std::queue<MoodEntry> MoodTracker::getRecentMoods() const {
    return recentMoodsQueue;
}

MoodEntry MoodTracker::getLastMood() const {
    if (moodHistory.empty()) {
        throw std::runtime_error("No mood entries available");
    }
    return moodHistory.back();
}

std::set<std::string> MoodTracker::getUniqueMoods() const {
    return uniqueMoods;
}

size_t MoodTracker::getUniqueMoodCount() const {
    return uniqueMoods.size();
}

bool MoodTracker::hasMood(const std::string& mood) const {
    return uniqueMoods.find(mood) != uniqueMoods.end();
}

std::vector<MoodEntry> MoodTracker::searchMoods(const std::string& searchTerm) const {
    std::vector<MoodEntry> results;
    
    for (const auto& entry : moodHistory) {
        if (entry.mood.find(searchTerm) != std::string::npos ||
            entry.notes.find(searchTerm) != std::string::npos) {
            results.push_back(entry);
        }
    }
    
    return results;
}

std::vector<MoodEntry> MoodTracker::getMoodsByType(const std::string& mood) const {
    std::vector<MoodEntry> results;
    
    for (const auto& entry : moodHistory) {
        if (entry.mood == mood) {
            results.push_back(entry);
        }
    }
    
    return results;
}

std::string MoodTracker::formatTimestamp(std::time_t timestamp) const {
    std::stringstream ss;
    ss << std::put_time(std::localtime(&timestamp), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

void MoodTracker::printMoodStatistics() const {
    std::cout << "\n=== MOOD STATISTICS (Using C++ Data Structures) ===\n";
    
    // Array/Vector Statistics
    std::cout << "\n📊 ARRAY/VECTOR - Complete Mood History:\n";
    std::cout << "Total entries: " << moodHistory.size() << std::endl;
    
    if (!moodHistory.empty()) {
        std::cout << "First entry: " << moodHistory.front().emoji << " " 
                  << moodHistory.front().mood << std::endl;
        std::cout << "Latest entry: " << moodHistory.back().emoji << " " 
                  << moodHistory.back().mood << std::endl;
    }
}

void MoodTracker::printRecentActivity() const {
    std::cout << "\n⏰ QUEUE - Recent Moods (FIFO - Last 5):\n";
    
    std::queue<MoodEntry> tempQueue = recentMoodsQueue;
    int position = 1;
    
    while (!tempQueue.empty()) {
        const MoodEntry& entry = tempQueue.front();
        std::cout << position << ". " << entry.emoji << " " << entry.mood;
        if (!entry.notes.empty()) {
            std::cout << " - \"" << entry.notes << "\"";
        }
        std::cout << std::endl;
        tempQueue.pop();
        position++;
    }
}

void MoodTracker::printMoodFrequencyChart() const {
    std::cout << "\n📈 MAP - Mood Frequency Analysis:\n";
    
    for (const auto& pair : moodFrequency) {
        std::cout << pair.first << ": ";
        // Create a simple bar chart
        for (int i = 0; i < pair.second; i++) {
            std::cout << "█";
        }
        std::cout << " (" << pair.second << ")" << std::endl;
    }
    
    std::cout << "\n💎 SET - Unique Moods Collection:\n";
    std::cout << "Total unique moods: " << uniqueMoods.size() << std::endl;
    std::cout << "Moods experienced: ";
    for (auto it = uniqueMoods.begin(); it != uniqueMoods.end(); ++it) {
        if (it != uniqueMoods.begin()) std::cout << ", ";
        std::cout << *it;
    }
    std::cout << std::endl;
}

void MoodTracker::demonstrateDataStructures() const {
    std::cout << "\n🔍 C++ DATA STRUCTURE DEMONSTRATIONS:\n";
    std::cout << "=====================================\n";
    
    printMoodStatistics();
    printRecentActivity();
    printMoodFrequencyChart();
    
    // Search demonstration
    std::cout << "\n🔍 SEARCH - Find Operations:\n";
    auto happyMoods = getMoodsByType("Happy");
    std::cout << "Found " << happyMoods.size() << " 'Happy' mood entries\n";
    
    if (!getMostFrequentMood().empty()) {
        std::cout << "Most frequent mood: " << getMostFrequentMood() 
                  << " (" << getMoodCount(getMostFrequentMood()) << " times)\n";
    }
}

// ========================
// GoalTracker Implementation
// ========================

void GoalTracker::pushGoal(const std::string& mood, const std::string& description) {
    MoodGoal goal(nextGoalId++, mood, description);
    goalStack.push(goal);
    std::cout << "✓ Added goal: " << mood << " - " << description << std::endl;
}

MoodGoal GoalTracker::popGoal() {
    if (goalStack.empty()) {
        throw std::runtime_error("No goals in stack");
    }
    
    MoodGoal goal = goalStack.top();
    goalStack.pop();
    return goal;
}

MoodGoal GoalTracker::peekTopGoal() const {
    if (goalStack.empty()) {
        throw std::runtime_error("No goals in stack");
    }
    
    return goalStack.top();
}

bool GoalTracker::hasGoals() const {
    return !goalStack.empty();
}

size_t GoalTracker::getGoalCount() const {
    return goalStack.size();
}

void GoalTracker::completeTopGoal() {
    if (goalStack.empty()) {
        std::cout << "No goals to complete!\n";
        return;
    }
    
    MoodGoal goal = popGoal();
    goal.isCompleted = true;
    completedGoals.push_back(goal);
    
    std::cout << "🎉 Completed goal: " << goal.targetMood << " - " 
              << goal.description << std::endl;
}

std::vector<MoodGoal> GoalTracker::getCompletedGoals() const {
    return completedGoals;
}

void GoalTracker::printGoalStack() const {
    std::cout << "\n🎯 STACK - Current Goals (LIFO - Last In, First Out):\n";
    
    if (goalStack.empty()) {
        std::cout << "No current goals. Add some to get started!\n";
        return;
    }
    
    std::stack<MoodGoal> tempStack = goalStack;
    int position = 1;
    
    while (!tempStack.empty()) {
        const MoodGoal& goal = tempStack.top();
        std::cout << position << ". " << goal.targetMood << " - " 
                  << goal.description << std::endl;
        tempStack.pop();
        position++;
    }
    
    std::cout << "\nCompleted goals: " << completedGoals.size() << std::endl;
}

void GoalTracker::demonstrateStackOperations() const {
    std::cout << "\n📚 STACK OPERATIONS DEMONSTRATION:\n";
    std::cout << "===================================\n";
    std::cout << "Stack follows LIFO (Last In, First Out) principle\n";
    std::cout << "- push(): Add goal to top of stack\n";
    std::cout << "- pop(): Remove and return top goal\n";
    std::cout << "- peek(): View top goal without removing\n";
    std::cout << "- isEmpty(): Check if stack has goals\n\n";
    
    printGoalStack();
}

// ========================
// JournalLinkedList Implementation
// ========================

JournalLinkedList::~JournalLinkedList() {
    JournalNode* current = head;
    while (current != nullptr) {
        JournalNode* next = current->next;
        delete current;
        current = next;
    }
}

void JournalLinkedList::addEntry(const std::string& title, const std::string& content) {
    JournalNode* newNode = new JournalNode(nextId++, title, content);
    
    // Insert at the beginning (most recent first)
    newNode->next = head;
    head = newNode;
    size++;
    
    std::cout << "✓ Added journal entry: " << title << std::endl;
}

void JournalLinkedList::addTag(int entryId, const std::string& tag) {
    JournalNode* entry = findEntry(entryId);
    if (entry != nullptr) {
        entry->tags.push_back(tag);
        std::cout << "✓ Added tag '" << tag << "' to entry " << entryId << std::endl;
    } else {
        std::cout << "❌ Entry " << entryId << " not found\n";
    }
}

JournalNode* JournalLinkedList::findEntry(int id) const {
    JournalNode* current = head;
    while (current != nullptr) {
        if (current->id == id) {
            return current;
        }
        current = current->next;
    }
    return nullptr;
}

void JournalLinkedList::deleteEntry(int id) {
    if (head == nullptr) return;
    
    // If head node is to be deleted
    if (head->id == id) {
        JournalNode* temp = head;
        head = head->next;
        delete temp;
        size--;
        std::cout << "✓ Deleted journal entry " << id << std::endl;
        return;
    }
    
    // Search for the node to delete
    JournalNode* current = head;
    while (current->next != nullptr && current->next->id != id) {
        current = current->next;
    }
    
    if (current->next != nullptr) {
        JournalNode* temp = current->next;
        current->next = current->next->next;
        delete temp;
        size--;
        std::cout << "✓ Deleted journal entry " << id << std::endl;
    } else {
        std::cout << "❌ Entry " << id << " not found\n";
    }
}

void JournalLinkedList::printAllEntries() const {
    std::cout << "\n📝 LINKED LIST - Journal Entries:\n";
    
    if (head == nullptr) {
        std::cout << "No journal entries yet. Start writing!\n";
        return;
    }
    
    JournalNode* current = head;
    while (current != nullptr) {
        std::cout << "\n--- Entry " << current->id << " ---\n";
        std::cout << "Title: " << current->title << std::endl;
        std::cout << "Content: " << current->content << std::endl;
        
        if (!current->tags.empty()) {
            std::cout << "Tags: ";
            for (size_t i = 0; i < current->tags.size(); i++) {
                if (i > 0) std::cout << ", ";
                std::cout << "#" << current->tags[i];
            }
            std::cout << std::endl;
        }
        
        std::cout << "Created: " << std::put_time(std::localtime(&current->timestamp), 
                                                   "%Y-%m-%d %H:%M:%S") << std::endl;
        current = current->next;
    }
}

std::vector<JournalNode*> JournalLinkedList::searchByTag(const std::string& tag) const {
    std::vector<JournalNode*> results;
    JournalNode* current = head;
    
    while (current != nullptr) {
        for (const std::string& entryTag : current->tags) {
            if (entryTag == tag) {
                results.push_back(current);
                break;
            }
        }
        current = current->next;
    }
    
    return results;
}

std::vector<JournalNode*> JournalLinkedList::searchByKeyword(const std::string& keyword) const {
    std::vector<JournalNode*> results;
    JournalNode* current = head;
    
    while (current != nullptr) {
        if (current->title.find(keyword) != std::string::npos ||
            current->content.find(keyword) != std::string::npos) {
            results.push_back(current);
        }
        current = current->next;
    }
    
    return results;
}

void JournalLinkedList::demonstrateLinkedListOperations() const {
    std::cout << "\n🔗 LINKED LIST OPERATIONS DEMONSTRATION:\n";
    std::cout << "=======================================\n";
    std::cout << "Linked List provides dynamic memory allocation\n";
    std::cout << "- addEntry(): Insert new node at head\n";
    std::cout << "- findEntry(): Traverse to find specific node\n";
    std::cout << "- deleteEntry(): Remove node and update links\n";
    std::cout << "- searchByTag(): Filter nodes by tag\n";
    std::cout << "- searchByKeyword(): Full-text search\n\n";
    
    printAllEntries();
}