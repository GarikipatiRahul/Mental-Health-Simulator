#ifndef MOOD_TRACKER_HPP
#define MOOD_TRACKER_HPP

#include <iostream>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <algorithm>
#include <chrono>
#include <ctime>

struct MoodEntry {
    int id;
    std::string mood;
    std::string emoji;
    std::string notes;
    std::time_t timestamp;
    
    MoodEntry(int id, const std::string& mood, const std::string& emoji, 
              const std::string& notes = "") 
        : id(id), mood(mood), emoji(emoji), notes(notes) {
        timestamp = std::time(nullptr);
    }
};

class MoodTracker {
private:
    // Array/Vector for storing complete mood history
    std::vector<MoodEntry> moodHistory;
    
    // Map for mood frequency counting
    std::map<std::string, int> moodFrequency;
    
    // Queue for recent moods (FIFO - First In, First Out)
    std::queue<MoodEntry> recentMoodsQueue;
    static const size_t MAX_RECENT_MOODS = 5;
    
    // Set for unique moods
    std::set<std::string> uniqueMoods;
    
    int nextId;

public:
    MoodTracker() : nextId(1) {}
    
    // Array/Vector Operations
    void addMoodEntry(const std::string& mood, const std::string& emoji, 
                      const std::string& notes = "");
    std::vector<MoodEntry> getMoodHistory() const;
    size_t getTotalMoodCount() const;
    
    // Map Operations - Frequency Analysis
    std::map<std::string, int> getMoodFrequency() const;
    std::string getMostFrequentMood() const;
    int getMoodCount(const std::string& mood) const;
    
    // Queue Operations - Recent Moods
    std::queue<MoodEntry> getRecentMoods() const;
    MoodEntry getLastMood() const;
    
    // Set Operations - Unique Moods
    std::set<std::string> getUniqueMoods() const;
    size_t getUniqueMoodCount() const;
    bool hasMood(const std::string& mood) const;
    
    // Search Operations
    std::vector<MoodEntry> searchMoods(const std::string& searchTerm) const;
    std::vector<MoodEntry> getMoodsByType(const std::string& mood) const;
    
    // Analytics
    void printMoodStatistics() const;
    void printRecentActivity() const;
    void printMoodFrequencyChart() const;
    
    // Utility functions
    std::string formatTimestamp(std::time_t timestamp) const;
    void demonstrateDataStructures() const;
};

// Goal Tracking using Stack (LIFO - Last In, First Out)
#include <stack>

struct MoodGoal {
    int id;
    std::string targetMood;
    std::string description;
    bool isCompleted;
    std::time_t createdAt;
    
    MoodGoal(int id, const std::string& mood, const std::string& desc)
        : id(id), targetMood(mood), description(desc), isCompleted(false) {
        createdAt = std::time(nullptr);
    }
};

class GoalTracker {
private:
    std::stack<MoodGoal> goalStack;
    std::vector<MoodGoal> completedGoals;
    int nextGoalId;

public:
    GoalTracker() : nextGoalId(1) {}
    
    // Stack Operations
    void pushGoal(const std::string& mood, const std::string& description);
    MoodGoal popGoal();
    MoodGoal peekTopGoal() const;
    bool hasGoals() const;
    size_t getGoalCount() const;
    
    // Goal Management
    void completeTopGoal();
    std::vector<MoodGoal> getCompletedGoals() const;
    void printGoalStack() const;
    void demonstrateStackOperations() const;
};

// Linked List for Mood Journal Entries
struct JournalNode {
    int id;
    std::string title;
    std::string content;
    std::vector<std::string> tags;
    std::time_t timestamp;
    JournalNode* next;
    
    JournalNode(int id, const std::string& title, const std::string& content)
        : id(id), title(title), content(content), next(nullptr) {
        timestamp = std::time(nullptr);
    }
};

class JournalLinkedList {
private:
    JournalNode* head;
    int nextId;
    size_t size;

public:
    JournalLinkedList() : head(nullptr), nextId(1), size(0) {}
    ~JournalLinkedList();
    
    // Linked List Operations
    void addEntry(const std::string& title, const std::string& content);
    void addTag(int entryId, const std::string& tag);
    JournalNode* findEntry(int id) const;
    void deleteEntry(int id);
    void printAllEntries() const;
    
    // Advanced Operations
    std::vector<JournalNode*> searchByTag(const std::string& tag) const;
    std::vector<JournalNode*> searchByKeyword(const std::string& keyword) const;
    size_t getSize() const { return size; }
    
    void demonstrateLinkedListOperations() const;
};

#endif // MOOD_TRACKER_HPP