#!/bin/bash

# Mental Wellness C++ Data Structures Compiler Script
echo "🧠 Compiling Mental Wellness C++ Data Structures Demo..."

# Create output directory if it doesn't exist
mkdir -p bin

# Compile the C++ program
g++ -std=c++17 -Wall -Wextra -O2 -o bin/mood_tracker main.cpp mood_tracker.cpp

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo "✓ Compilation successful!"
    echo ""
    echo "🎯 Running Mental Wellness Data Structures Demo..."
    echo "=================================================="
    
    # Run the program
    ./bin/mood_tracker
else
    echo "❌ Compilation failed. Please check the code for errors."
    exit 1
fi