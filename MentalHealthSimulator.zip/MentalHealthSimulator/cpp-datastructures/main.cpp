#include "mood_tracker.hpp"
#include <iostream>
#include <string>

void showMenu() {
    std::cout << "\n=== MENTAL WELLNESS C++ DATA STRUCTURES DEMO ===\n";
    std::cout << "1. Add Mood Entry (Array/Vector, Map, Queue, Set)\n";
    std::cout << "2. View Mood Statistics\n";
    std::cout << "3. Add Mood Goal (Stack)\n";
    std::cout << "4. Complete Goal (Stack Pop)\n";
    std::cout << "5. View Goals Stack\n";
    std::cout << "6. Add Journal Entry (Linked List)\n";
    std::cout << "7. View Journal Entries\n";
    std::cout << "8. Search Journal by Tag\n";
    std::cout << "9. Demonstrate All Data Structures\n";
    std::cout << "0. Exit\n";
    std::cout << "Choose an option: ";
}

int main() {
    MoodTracker tracker;
    GoalTracker goalTracker;
    JournalLinkedList journal;
    
    std::cout << "🧠 Welcome to Mental Wellness C++ Data Structures Demo!\n";
    std::cout << "This demo shows how data structures work in a mental health context.\n";
    
    // Add some sample data for demonstration
    tracker.addMoodEntry("Happy", "😊", "Had a great morning walk");
    tracker.addMoodEntry("Calm", "😌", "Meditation session helped");
    tracker.addMoodEntry("Excited", "🤩", "Got promotion at work!");
    tracker.addMoodEntry("Sad", "😢", "Feeling lonely today");
    tracker.addMoodEntry("Happy", "😊", "Spent time with friends");
    
    goalTracker.pushGoal("Calm", "Practice meditation for 10 minutes daily");
    goalTracker.pushGoal("Happy", "Exercise 3 times this week");
    goalTracker.pushGoal("Grateful", "Write in gratitude journal daily");
    
    journal.addEntry("My Meditation Journey", "Started practicing mindfulness today. It feels peaceful.");
    journal.addTag(1, "meditation");
    journal.addTag(1, "mindfulness");
    
    journal.addEntry("Workout Success", "Completed my first 5K run! Feeling accomplished.");
    journal.addTag(2, "exercise");
    journal.addTag(2, "achievement");
    
    int choice;
    std::string mood, emoji, notes, title, content, tag, keyword;
    
    while (true) {
        showMenu();
        std::cin >> choice;
        std::cin.ignore(); // Clear the newline character
        
        switch (choice) {
            case 1: {
                std::cout << "\n=== ADD MOOD ENTRY ===\n";
                std::cout << "Available moods: Happy, Sad, Angry, Calm, Excited, Anxious\n";
                std::cout << "Enter mood: ";
                std::getline(std::cin, mood);
                std::cout << "Enter emoji: ";
                std::getline(std::cin, emoji);
                std::cout << "Enter notes (optional): ";
                std::getline(std::cin, notes);
                
                tracker.addMoodEntry(mood, emoji, notes);
                break;
            }
            
            case 2: {
                tracker.demonstrateDataStructures();
                break;
            }
            
            case 3: {
                std::cout << "\n=== ADD MOOD GOAL ===\n";
                std::cout << "Enter target mood: ";
                std::getline(std::cin, mood);
                std::cout << "Enter goal description: ";
                std::getline(std::cin, content);
                
                goalTracker.pushGoal(mood, content);
                break;
            }
            
            case 4: {
                std::cout << "\n=== COMPLETE GOAL ===\n";
                goalTracker.completeTopGoal();
                break;
            }
            
            case 5: {
                goalTracker.demonstrateStackOperations();
                break;
            }
            
            case 6: {
                std::cout << "\n=== ADD JOURNAL ENTRY ===\n";
                std::cout << "Enter title: ";
                std::getline(std::cin, title);
                std::cout << "Enter content: ";
                std::getline(std::cin, content);
                
                journal.addEntry(title, content);
                
                std::cout << "Add tags? (y/n): ";
                std::string addTags;
                std::getline(std::cin, addTags);
                
                if (addTags == "y" || addTags == "Y") {
                    int entryId = journal.getSize(); // Latest entry ID
                    std::cout << "Enter tag (or 'done' to finish): ";
                    while (std::getline(std::cin, tag) && tag != "done") {
                        journal.addTag(entryId, tag);
                        std::cout << "Enter another tag (or 'done' to finish): ";
                    }
                }
                break;
            }
            
            case 7: {
                journal.demonstrateLinkedListOperations();
                break;
            }
            
            case 8: {
                std::cout << "\n=== SEARCH JOURNAL ===\n";
                std::cout << "Enter tag to search for: ";
                std::getline(std::cin, tag);
                
                auto results = journal.searchByTag(tag);
                std::cout << "\nFound " << results.size() << " entries with tag '" << tag << "':\n";
                
                for (const auto* entry : results) {
                    std::cout << "- " << entry->title << ": " << entry->content << std::endl;
                }
                break;
            }
            
            case 9: {
                std::cout << "\n🎓 COMPREHENSIVE DATA STRUCTURES DEMONSTRATION\n";
                std::cout << "=============================================\n";
                
                // Demonstrate all data structures
                tracker.demonstrateDataStructures();
                goalTracker.demonstrateStackOperations();
                journal.demonstrateLinkedListOperations();
                
                std::cout << "\n📚 DATA STRUCTURE SUMMARY:\n";
                std::cout << "==========================\n";
                std::cout << "• ARRAY/VECTOR: Sequential storage, fast random access\n";
                std::cout << "• MAP: Key-value pairs, fast lookup and counting\n";
                std::cout << "• QUEUE: FIFO (First In, First Out) - recent moods\n";
                std::cout << "• SET: Unique elements only - distinct moods\n";
                std::cout << "• STACK: LIFO (Last In, First Out) - goal management\n";
                std::cout << "• LINKED LIST: Dynamic nodes, efficient insertion/deletion\n";
                break;
            }
            
            case 0: {
                std::cout << "\n👋 Thank you for exploring C++ data structures!\n";
                std::cout << "Remember: Taking care of your mental health is important.\n";
                std::cout << "These data structures help organize and analyze wellness data.\n";
                return 0;
            }
            
            default: {
                std::cout << "❌ Invalid option. Please try again.\n";
                break;
            }
        }
        
        std::cout << "\nPress Enter to continue...";
        std::cin.ignore();
    }
    
    return 0;
}