# Mental Wellness Companion

## Overview

This is a comprehensive full-stack mental wellness application built with React, Express, and PostgreSQL database. The application provides a complete mental health ecosystem with mood logging, motivational quotes, breathing exercises, analytics dashboard, and advanced wellness tools including goal setting, journaling, streak tracking, and daily affirmations. It uses a modern tech stack with TypeScript, Tailwind CSS, and shadcn/ui components for a polished user experience. The project also includes educational C++ implementations of all data structures used in the web application for learning purposes.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints for mood logging and session management
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Data Storage**: PostgreSQL with Neon Database serverless connection
- **Session Storage**: Database-backed session management with DatabaseStorage implementation

### C++ Educational Component
- **Data Structures**: Complete C++ implementations of all web app data structures
- **Interactive Demo**: Command-line program with menu-driven interface
- **Educational Value**: Demonstrates Array/Vector, Map, Queue, Set, Stack, and Linked List operations
- **Learning Resource**: Header files, source code, and comprehensive documentation

### Key Components

#### Database Schema
- **users**: User authentication and profile data
- **mood_entries**: Mood logs with emoji, notes, and timestamps
- **sessions**: Client-side session management for temporary users

#### API Endpoints
- `GET /api/session/:name` - Retrieve user session data
- `POST /api/moods` - Log new mood entries
- `GET /api/quote` - Fetch random motivational quotes

#### Frontend Flow
1. **Welcome Screen**: Name collection and session initialization
2. **Mood Logging**: Interactive mood selection with emoji interface
3. **Quote Display**: Motivational content after mood logging
4. **Breathing Exercise**: Guided 4-4-4-2 breathing pattern with 10 cycles
5. **Dashboard**: Analytics with mood frequency charts and search functionality
6. **Mood Goals**: Set and track emotional wellness targets
7. **Mood Journal**: Write detailed thoughts and feelings with tags
8. **Mood Streaks**: Track daily check-in consistency and achievements
9. **Daily Affirmations**: Positive mindset reinforcement with categories

## Data Flow

1. User enters name on welcome screen
2. Session created/retrieved from backend storage
3. User logs mood with emoji and optional notes
4. Mood entry saved to database and session updated
5. Motivational quote fetched from static collection
6. Optional breathing exercise with timer-based phase transitions
7. Dashboard displays mood analytics with data structures demonstrations

## External Dependencies

### Core Libraries
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight React router
- **framer-motion**: Animation library for breathing exercise

### UI Components
- **@radix-ui/***: Accessible component primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Tools
- **vite**: Build tool and dev server
- **tsx**: TypeScript execution for server
- **esbuild**: Production bundling

## Deployment Strategy

### Build Process
- Frontend built with Vite to `dist/public`
- Backend bundled with esbuild to `dist/index.js`
- TypeScript compilation with strict mode enabled

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `NODE_ENV`: Environment mode (development/production)

### Production Setup
- Single Node.js process serving both API and static files
- Express middleware for API routes
- Static file serving for React SPA
- Database migrations managed through Drizzle Kit

### Development Features
- Hot module replacement with Vite
- Replit-specific development banner
- Runtime error overlay for debugging
- Automatic database schema synchronization

The application demonstrates modern full-stack development patterns with emphasis on mental health and user experience, including data structure algorithms for mood analytics and responsive design for accessibility.